##Build OSX:##
You have to get a Developer ID certificate from Apple and install it into your Mac’s Keychain ([How to](http://www.pracucci.com/atom-electron-signing-mac-app.html))

Add to environment:

	export MAC_APP_CERT_IDENTITY=${your certificate identity}

Run this commands in your terminal, all builds are located at ${projectFolder}/builds/mac/:

* Build and sign VydeoGram.app

	> npm run buildx

* Build and sign VydeoGram.app and package it to VydeoGram.dmg

	> npm run buildx-release


##Build Windows:##
If you are building application not from Windows OS you will have to install Wine first. Run command below to get build at ${projectFolder}/builds/win/:

* Build VydeoGram.exe

	> npm run buildwin

* To build installer you need Windows OS. You have to install [NSIS](http://nsis.sourceforge.net/Download) and [Script Generator](http://nsis.sourceforge.net/NSIS_Quick_Setup_Script_Generator)

	1. Run 'NSIS Quick Setup Script', Load previous project 'tasks/installer-win/resources/VydeoGram.ini'.
	2. Check info and choose project folder.
	3. Generate script. If you want to change icon add after !include "MUI.nsh"
		>  !define MUI_ICON "path_to_icon"
	4. Run script

* To sign installer you need .cer file here [guide](https://msdn.microsoft.com/en-us/library/windows/hardware/ff553467%28v=vs.85%29.aspx) how to sign. If you want to create test cer look at [this page](https://msdn.microsoft.com/en-us/library/windows/hardware/ff548693%28v=vs.85%29.aspx).
