var app = require('app');
var path = require('path');
var sep = path.sep;
var browser = require('browser-window');
var amember = require(__dirname + sep + 'js' + sep + 'amember.js');
var appJs = require(__dirname + sep + 'js' + sep + 'app.js');
var fs = require('fs');
var Menu = require('menu');
var Youtube = require('./js/youtubeAuthorization.js');


app.commandLine.appendSwitch('--disable-http-cache');
var mainWindow = null;
app.on('window-all-closed', function() {
  if (process.platform != 'darwin') {
    app.quit();
  }
});
var host = '';

app.on('ready', function () {
  mainWindow = new browser({
    width: 800,
    height: 700,
    "min-width": 760,
    "min-height": 660
  });
  mainWindow.on('close',function(){
    mainWindow = null;
  });
  var webContents = mainWindow.webContents;
  mainWindow.on('closed', function() {
    // Dereference the window object, usually you would store windows
    // in an array if your app supports multi windows, this is the time
    // when you should delete the corresponding element.
    mainWindow = null;
  });

  console.log(app.getPath('appData'));
  mainWindow = mainWindow.webContents;
  //mianWindow.loadUrl('file://' + __dirname + '/views/index.html');
  //mainWindow.openDevTools();

  function updateLicense(licenseKey, lastCheckDate) {
    var pathToLicense = path.join(__dirname, 'license', 'license.json');
    var license = {
      'license': licenseKey,
      'lastCheckDate': lastCheckDate
    };
    var text = JSON.stringify(license);
    fs.writeFile(pathToLicense, text, function (err) {
      if (err) {
        return console.log(err);
      }
      console.log("The file was saved!");
    });
  }

  exports.loadStartPage = function () {
    mainWindow.loadUrl('file://' + __dirname + '/views/mainBack.html');
  };

  exports.loadLogInPage = function () {
    mainWindow.loadUrl('file://' + __dirname + '/views/index.html');
  };

  //updateLicense('3TBUQ8MR91', 'December 20, 2015 11:13:00');

  var pathToLicense = path.join(__dirname, 'license', 'license.json');
  fs.readFile(pathToLicense, 'utf8', (function (err, data) {
    if (err) throw err;
    var jsonLicense = JSON.parse(data);
    var licenseKey = jsonLicense.license;


    var lastCheckDate = new Date(jsonLicense.lastCheckDate);

    function loadStartPage() {
      mainWindow.loadUrl('file://' + __dirname + '/views/mainBack.html');
    }

    function loadOfflinePage() {
      mainWindow.loadUrl('file://' + __dirname + '/views/index.html');
    }

    function loadLogInPage2() {
      mainWindow.executeJavaScript("var app = require('../js/app.js');app.clearTemp(function () {window.onbeforeunload = function(){};var index = require('remote').require('./index.js');});");
      mainWindow.loadUrl('file://' + __dirname + '/views/index.html');
    }

    function isOnline() {

    }

    function showMsg(msg) {
      mainWindow.executeJavaScript("var app = require('../js/app.js');app.clearTemp(function () {window.onbeforeunload = function(){};var index = require('remote').require('./index.js');});");
      mainWindow.loadUrl('file://' + __dirname + '/views/index.html');
      console.log(licenseKey);
      mainWindow.executeJavaScript('message(\'' + msg + '\', \'error\');');
    }

    if (licenseKey !== '') {
      amember.logIn(licenseKey, lastCheckDate, showMsg, function() {}, loadOfflinePage, loadLogInPage2);
      loadStartPage();
    } else {
      mainWindow.loadUrl('file://' + __dirname + '/views/index.html');
      var msg = 'remote-msg';
      mainWindow.executeJavaScript('console.log(\'' + msg + '\');');
    }

  }).bind(this));

//-------------------For Youtube--------------------
  var googleWebContents = '';
  var googleWindow = '';

  function createGoogleWindow (url) {
    googleWindow = new BrowserWindow({
      width: 500,
      height: 550,
      'web-preferences' : {
        'web-security' : false
      }
    });
    googleWebContents =  googleWindow.webContents;
    googleWebContents.loadUrl(url);
  }

  var youtube = new Youtube(webContents, createGoogleWindow);
  //console.log(youtube);

  exports.closeGoogleWindow = function () {
    googleWindow.destroy();
  };


  function loadLogInPage() {
      mainWindow.loadUrl('file://' + __dirname + '/views/index.html');
  }

  function loadStartPage() {
    mainWindow.loadUrl('file://' + __dirname + '/views/mainBack.html');
  }

  function showMsg(msg) {
    mainWindow.executeJavaScript('message(\'' + msg + '\', \'error\');');
    mainWindow.executeJavaScript("$('.login-loader,.login-loader img').css('display', 'none');$('.boxForLoader').css('display', 'block');");
  }

  exports.logIn = function(licenseKeyFromInput, onlineChecker) {

    amember.logIn(licenseKeyFromInput, '', showMsg, loadStartPage, '', onlineChecker);
  }

  exports.deactivateLicense = function () {
    amember.deactivateLicense(mainWindow, loadLogInPage);
  }


  function loadLogInPage() {
      mainWindow.loadUrl('file://' + __dirname + '/views/index.html');
  }

  function loadStartPage() {
    mainWindow.loadUrl('file://' + __dirname + '/views/mainBack.html');
  }

  function showMsg(msg) {
    mainWindow.executeJavaScript('message(\'' + msg + '\', \'error\');');
    mainWindow.executeJavaScript("$('.login-loader,.login-loader img').css('display', 'none');$('.boxForLoader').css('display', 'block');");
  }

  exports.logIn = function(licenseKeyFromInput, onlineChecker) {

    amember.logIn(licenseKeyFromInput, '', showMsg, loadStartPage, '', onlineChecker);
  }

  exports.deactivateLicense = function () {
    amember.deactivateLicense(mainWindow, loadLogInPage);
  }

  //googleWindow.loadUrl('http://electron.atom.io/docs/v0.33.0/');

  exports.youtubeUploadVideo = function(videoName, processProgress, onSuccess) {
    //youtube.authorize(webContents, 'youtubeUploadVideo', '', youtube.uploadVideo, [videoName, processProgress]);
    youtube.uploadVideo(videoName, processProgress, onSuccess);
  };

  //webContents.openDevTools();
//---------------------------------------------------
});

app.once('ready', function () {
  if (Menu.getApplicationMenu())
    return;

  var template = [
    {
      label: "File",
      submenu: [
        {
          label: 'Close',
          accelerator: 'CmdOrCtrl+W',
          role: 'close'
        }
      ]},
    {
      label: 'Edit',
      submenu: [
        {
          label: 'Undo',
          accelerator: 'CmdOrCtrl+Z',
          role: 'undo'
        },
        {
          label: 'Redo',
          accelerator: 'Shift+CmdOrCtrl+Z',
          role: 'redo'
        },
        {
          type: 'separator'
        },
        {
          label: 'Cut',
          accelerator: 'CmdOrCtrl+X',
          role: 'cut'
        },
        {
          label: 'Copy',
          accelerator: 'CmdOrCtrl+C',
          role: 'copy'
        },
        {
          label: 'Paste',
          accelerator: 'CmdOrCtrl+V',
          role: 'paste'
        },
        {
          label: 'Select All',
          accelerator: 'CmdOrCtrl+A',
          role: 'selectall'
        }
      ]
    },
    {
      label: 'License',
      submenu: [
        {
          label: 'Deactivate',
          click: function () {
            function loadLogInPage() {
              mainWindow.loadUrl('file://' + __dirname + '/views/index.html');
            }
            amember.deactivateLicense(mainWindow, loadLogInPage);
          }
        }
      ]
    }
  ];

  if (process.platform == 'darwin') {
    var name = require('app').getName();
    template.unshift({
      label: name,
      submenu: [
        {
          label: 'Quit',
          accelerator: 'Command+Q',
          click: function () {
            app.quit();
          }
        }
      ]
    });
  }


  var menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);
});
