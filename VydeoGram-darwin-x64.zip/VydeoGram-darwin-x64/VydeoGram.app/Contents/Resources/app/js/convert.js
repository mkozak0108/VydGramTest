"use strict";

module.exports = function convert() {
  var fs = require('fs');
  var path = require('path');
  var sep = path.sep;
  var linkHelper = require('..' + sep + 'js' + sep + 'linkHelper');
  var timeTransform = require(linkHelper.getJs("timeTransform.js"));
  var gifHelp = require(linkHelper.getJs("gifHelp.js"));
  var ffmpegHelp = require(linkHelper.getJs("ffmpegHelp.js"));
  var app = require(linkHelper.getJs('app.js'));
  var BackHelp = require(linkHelper.getJs('backHelp.js'));
  var Tooltip = require(linkHelper.getVendorJs('tooltip.js'));
  var MyProjects = require(linkHelper.getJs('myProjects.js'));
  var Slider = require(linkHelper.getJs('slider.js'));

  var firstEditPrev;
  var secondEditPrev;
  var NUMBER_PICKER_STEP = 10;
  var NUMBER_OF_ZERO = 10;
  var NUMBER_MIN = app.MIN_GIF_DURATION;
  var MAX_GIF_DURATION = app.MAX_GIF_DURATION;
  var DEFAULT_LUFT = 5;

  BackHelp.clear();
  var $head = $('head');
  var filePathName = app.uploadedFile.path;
  app.clearTemp(function () {

    ffmpegHelp.getData(filePathName, function (data) {
      var videoData = data.streams[0];

      $head.append('<link rel="stylesheet" href="' + '../css/convert.css"/>');
      $('<link rel="stylesheet" href="../vendor/css/bootstrap-slider.min.css"/>' +
        '<link rel="stylesheet" href="../vendor/css/tooltip.css"/>')
        .insertBefore('link[href="../css/mainBtns.css"]');
      $head.append('<link rel="stylesheet" href="../css/roundProgressBar.css"/>');
      //$('<link rel="stylesheet" href="../vendor/css/tooltip.css"/>')
      //  .insertBefore('link[href="../css/mainBtns.css"]');

      //var BootsrapSlider = require(linkHelper.getAbsolute('vendor', 'js', 'bootstrap-slider.min.js'));

      $('#msg').after($('<div>').load("convert.html", function () {
        var tip = new Tooltip('VydeoGram Max Length is set to 30 sec');
        var tip$selector = '.left .fa-question.hint-button';
        var $question = $(tip$selector);
        tip.effect('fade');
        tip.place('top-right');
        //tip.type('light');
        $question.mouseenter(function () {
          tip.position(document.querySelector(tip$selector)).show();
          var $tooltip = $('.tooltip.fade.top-right.in');
          var num = $tooltip.css('left');
          num = parseFloat(num.substring(0, num.length - 2));
          num -= 9;
          $tooltip.css('left', num + 'px');
        });
        $question.mouseleave(function () {
          tip.hide();
        });

        var $newBtn = $('.header .btn-new');
        $newBtn.click(function () {
          require(linkHelper.getJs('dAndD.js'))();
        });
        $newBtn.removeClass('pushed');
        app.whereBackMyProjects = 1;

        var max = Math.floor(data.format.duration);
        app.duration = max;

        linkHelper.getTempPath();
        var firstScreenTime = 1;
        if (app.duration < 30)firstScreenTime = parseFloat((app.duration * 0.1).toFixed(3));

        //ffmpegHelp.getScreen2 = function (input, time, output, cb, cbParams) {
        ffmpegHelp.getScreen2(filePathName, firstScreenTime, linkHelper.getTempPath() + sep + 'screen.png',
          function (outputPathName) {
            console.log(outputPathName);
            $('.ConvertContent .right').html('<img src="file://' + outputPathName + '?' + Date.now() + '" >');
            app.addToDelete(outputPathName);
          },
          linkHelper.getTempPath() + sep + 'screen.png');

        var step = 1;
        var slider = new Slider('.left', step, max, 0);
        var slideMin = 0, slideMax = max;

        if (!(app.gifDuration && app.gifDuration >= app.MIN_GIF_DURATION && app.gifDuration <= app.MAX_GIF_DURATION))app.gifDuration = 8;
        if (!(app.startTime && app.startTime >= 0 && app.startTime <= app.duration))app.startTime = slideMin;
        if (!(app.endTime && app.endTime >= 0 && app.endTime <= app.duration))app.endTime = slideMax;

        slideMin = app.startTime;
        slideMax = app.endTime;

        slideMin = Math.floor(slideMin);
        slideMax = Math.floor(slideMax);
        slider.init();
        slider.setValue([slideMin, slideMax]);
        slider.init(slideMin, slideMax);

        $('.numberPicker > .number').val(setNumber(app.gifDuration));
        var $numberPicker = $('.numberPicker');

        function clearNumber(str) {
          return str.replace(/sec/g, '');
        }

        function setNumber(str) {
          return str + " sec"
        }

        require(linkHelper.getJs('numberPicker.js'))($numberPicker,
          $numberPicker.find('.number').val(), NUMBER_PICKER_STEP, NUMBER_OF_ZERO,
          MAX_GIF_DURATION, NUMBER_MIN, clearNumber, setNumber);

        $('.ConvertContent > .mainBtn').click(function () {
          var startEnd = slider.getValue();
          var startTime = startEnd[0];
          var endTime = startEnd[1];
          var strNum = $('.numberPicker > .number').val();
          if (!strNum) strNum = '8 sec';
          var gifTime = parseFloat(clearNumber(strNum));
          gifTime = Math.round(gifTime);
          app.gifDuration = gifTime;
          app.startTime = startTime;
          app.endTime = endTime;
          function DO() {
            function cbGifCreate(imageOut) {
              require(linkHelper.getJs('videoGramPreview.js'))();
            }

            (new BackHelp($('.back'))).remove();
            var timeArr = ffmpegHelp.getTimes(app.startTime, app.endTime);

            console.log('st:' + app.startTime + '  end:' + app.endTime);
            var $ConvertContent = $('.ConvertContent');
            $ConvertContent.find('.top').attr('class', 'top white-text');
            $ConvertContent.find('.top').text('Generating VydeoGram');
            $ConvertContent.find('.left').remove();
            $ConvertContent.find('.right').remove();
            app.randomizeNot = false;
            $('<link[href="../css/convert.css"]/>').remove();
            $ConvertContent.append($('<div>')
              .load("roundProgressBar.html", function () {
                require(linkHelper.getJs("createGifFunc.js"))
                (filePathName, timeArr, app.width, app.height, app.quality, '.roundProgressBar',
                  cbGifCreate);
              }));
          }

          DO();
        });
        (new BackHelp($('.back'))).add(app.back[0]);
      }));
    });
  });
};
