var fs = require("fs");
var path = require('path');
var sep = path.sep;
var linkHelper = require('..' + sep + 'js' + sep + 'linkHelper.js');
var app = require(linkHelper.getJs('app.js'));
var appDataDir = require('remote').require('app').getPath('appData') + sep + "VydeoGramm";
var mkdirp = require(linkHelper.getJs('mkdirp'));
var rimraf = require("rimraf");
var moment = require("moment");
var DATE_FORMAT = "MMM D, YYYY, h:mm A";
function clearCss() {
  $('head').find('link')
    .not('link[href="../css/mainBtns.css"]')
    .not('link[href="../css/mainBack.css"]')
    .remove();
}

function getDirectories(srcpath) {
  var fs = require("fs");
  return fs.readdirSync(srcpath).filter(function (file) {
    return fs.statSync(path.join(srcpath, file)).isDirectory();
  });
}

function MyProjects() {
  var elements = [];

  function checkPath(imgFilePath, cbGood, cbBad) {
    if (fs.existsSync(imgFilePath + sep + 'gif.gif') &&
      fs.existsSync(imgFilePath + sep + 'gif.json') &&
      MyProjects.getJson(imgFilePath).prNameDir) {
      if (cbGood)cbGood();
    } else {
      rimraf(imgFilePath, function () {
        if (cbBad)cbBad();
      });
    }
  }

  function getVid(imgFilePath, i, cb) {
    MyProjects.myPrOrNotClick(true);
    var $newLast = $('<div class="VID">');
    $newLast.append(new Image());
    var json = MyProjects.getJson(imgFilePath);
    var duration = json.gifDuration;
    duration = Math.round(parseFloat(duration) * 10) / 10;
    var name = json.prNameDir;
    //$newLast.append($('<div class="delete btn-shine">x</div>'));
    $newLast.append($('<div class="name white-text">'));
    $newLast.append($('<div class="time white-text">'));
    $newLast.append($('<div class="duration white-text">'));
    $newLast.find('img').attr('src', imgFilePath + sep + 'gif.gif');
    $newLast.find('.name').html(MyProjects.getName(name));
    $newLast.find('.time').html(moment(MyProjects.getDate(name).toJSON()).format(DATE_FORMAT));
    $newLast.find('.duration').html(duration + ' s');
    $newLast.attr('index', i);
    return $newLast;
  }

  this.get = function () {
    var $newBtn = $('.header .btn-new');
    $newBtn.click(function () {
      require(linkHelper.getJs('dAndD.js'))();
    });
    $newBtn.removeClass('pushed');

    var $body = $('body');
    var $head = $('head');
    $body.children().not('#msg, .header, script').remove();
    var BackHelp = require(linkHelper.getJs('backHelp.js'));
    clearCss();
    $head.append('<link rel="stylesheet" href="../css/myProjects.css"/>');
    $body.append($('<div class="myProjectsBack">').load('myProjects.html', function () {
      mkdirp(appDataDir);
      function copy(src, dest) {
        var oldFile = fs.createReadStream(src);
        var newFile = fs.createWriteStream(dest);
        oldFile.pipe(newFile);
      }

      function copyDir(src, dest) {
        mkdirp(dest);
        var files = fs.readdirSync(src);
        for (var i = 0; i < files.length; i++) {
          var current = fs.lstatSync(path.join(src, files[i]));
          if (current.isDirectory()) {
            copyDir(path.join(src, files[i]), path.join(dest, files[i]));
          } else if (current.isSymbolicLink()) {
            var symlink = fs.readlinkSync(path.join(src, files[i]));
            fs.symlinkSync(symlink, path.join(dest, files[i]));
          } else {
            copy(path.join(src, files[i]), path.join(dest, files[i]));
          }
        }
      }

      elements = getDirectories(MyProjects.appDataDir);
      if (elements.length) {
        function compare(a, b) {
          var fir = parseFloat((new Date(a.find('.time').text())).getTime());
          var sec = parseFloat((new Date(b.find('.time').text())).getTime());
          if (fir < sec)
            return 1;
          if (fir > sec)
            return -1;
          return 0;
        }

        //elements.sort(compare);
        var $elements = [];
        for (var jj = 0; jj < elements.length; ++jj) {
          checkPath(MyProjects.appDataDir + sep + elements[jj], function () {
            $elements.push(getVid(MyProjects.appDataDir + sep + elements[jj], jj));
          });
        }
        $elements.sort(compare);

        function appendPr($pr) {
          $('.myProjects').find('.VID').last().after($pr);
        }

        $('.myProjects').html($elements[0]);
        for (var i = 1; i < $elements.length; ++i) {
          appendPr($elements[i]);
        }

        $('.VID').click(function () {
          var $where = $(this);
          app.duration = undefined;
          app.imageOut = $(this).find('img').attr('src');
          app.clearTemp(function () {
            var from = MyProjects.appDataDir + sep + elements[parseInt($where.attr('index'))];
            copyDir(from, linkHelper.getTempPath());
            var temps = fs.readdirSync(linkHelper.getTempPath());
            for (var i = 0; i < temps.length; ++i) {
              app.addToDelete(temps[i]);
            }
            app.randomizeNot = true;
            app.appDataPrNameDir = from;
            require(linkHelper.getJs(app.back[2]))();
            app.whereBackMyProjects = -1;
          });
        });
      }
    }));
  };

}

MyProjects.appDataDir = appDataDir;
mkdirp(appDataDir);

function normalizeTimeForOs(str) {
  return str.replace(/:/g, '$%$~_-');
}

function normalizeTimeForPr(str) {
  return str.replace(/\$\%\$\~_-/g, ':');
}

MyProjects.getJson = function (strName) {
  return JSON.parse(fs.readFileSync(strName + sep + 'gif.json', 'utf-8'));
};

MyProjects.setJson = function (strName, objectData) {
  fs.writeFileSync(strName + sep + 'gif.json', JSON.stringify(objectData), 'utf-8', function (err) {
    if (err) {
      message(err, "error");
      console.log(err);
    }
  });
};

MyProjects.getName = function (strName) {
  return strName.substring(strName.lastIndexOf(sep) + 1, strName.lastIndexOf('__'));
};
MyProjects.getDateStr = function (str) {
  return str.substring(str.lastIndexOf("__") + 2, str.length);
};
MyProjects.getDate = function (str) {
  return new Date(parseInt(MyProjects.getDateStr(str)));
};

MyProjects.getFolderNameTime = function (val, time) {
  var dir = appDataDir + sep + val + "__" + time;
  mkdirp(dir);
  return dir;
};

MyProjects.getFolderName = function (val) {
  return MyProjects.getFolderNameTime(val, (new Date()).getTime());
};

MyProjects.myPrOrNotClick = function (myPrOrNot) {
  var linkHelper = require('..' + sep + 'js' + sep + 'linkHelper.js');
  var BackHelp = require(linkHelper.getJs('backHelp.js'));
  var app = require(linkHelper.getJs('app.js'));

  if (typeof myPrOrNot !== "boolean")myPrOrNot = true;
  var $header = $(".header").find(".flex");
  var $myProjects = $header.find(".MyProjects");
  var $mainMenu = $header.find(".MainMenu");

  function onClickBefore() {
    clearCss();
    $('body').children().not('#msg, .header, script, .forbidden-icon.hide').remove();
  }

  function myPrOrNotHelp($btn) {
    $header.children().removeClass("pushed");
    $header.children().off();
    $btn.addClass("pushed");
  }

  if (myPrOrNot) {
    myPrOrNotHelp($myProjects);
    $mainMenu.click(function () {
      message();
      onClickBefore();
      MyProjects.myPrOrNotClick(false);
      //BackHelp.doFunc(app.back[0]);
      BackHelp.doFunc(app.back[app.whereBackMyProjects])
    });
  } else {
    myPrOrNotHelp($mainMenu);
    $myProjects.click(function () {
      message();
      onClickBefore();
      MyProjects.myPrOrNotClick(true);
      (new MyProjects).get();
    });
  }
};

module.exports = MyProjects;
