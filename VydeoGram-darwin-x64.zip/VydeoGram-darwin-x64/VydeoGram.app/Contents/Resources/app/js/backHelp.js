"use strict";

function BackHelp($back) {
  var path = require('path');
  var sep = path.sep;
  var linkHelper = require('..' + sep + 'js' + sep + 'linkHelper.js');
  this.add = function (back, backParams) {
    if (!$back.length) {
      $('#msg').after($('<div class="back icon">'));
      $back = $('.back');
      $back.attr('data-icon', 'w');
      $back.html('<span class="back-title">Back</span>');
    }
    $back.off();
    $back.click(function () {
      BackHelp.doFunc(back, backParams);
    });
    $back.removeClass('non-display');
  };
  this.remove = function () {
    $back.off();
    $back.addClass('non-display');
    $back.remove();
  };
}

BackHelp.doFunc = function (back, backParams) {
  message();
  if (typeof back === "function") {
    if (backParams)back(backParams);
    else back();
  }
  else {
    var func = require(linkHelper.getJs(back));
    if (typeof func === "function")func();
    else require(linkHelper.getJs(back));
  }
};

BackHelp.clear = function (selector$NotRemove) {
  var $out = $('body').children();
  if (selector$NotRemove) $out.not(selector$NotRemove).remove();
  else $out.not('#msg, .header, script, .back, .forbidden-icon.hide').remove();

  $('head').find('link')
    .not('link[href="../css/mainBtns.css"]')
    .not('link[href="../css/mainBack.css"]')
    .remove();
};

module.exports = BackHelp;
