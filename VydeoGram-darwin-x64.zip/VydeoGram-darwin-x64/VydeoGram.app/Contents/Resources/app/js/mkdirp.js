"use strict";

var path = require('path');
var sep = path.sep;
var linkHelper = require('..' + sep + 'js' + sep + 'linkHelper.js');
var mkdir = require('mkdirp');

function mkdirp(path, cb) {
  mkdir(mkdirp.formPath(path), cb);
}

mkdirp.formPath = function (path) {
  if (/^win/.test(process.platform)) {
    return path.replace(/\\/g, '/');
  } else {
    return path;
  }
};
module.exports = mkdirp;
