function Slider(str$where, step, max, min, onChange) {

  var path = require('path');
  var sep = path.sep;
  var linkHelper = require('..' + sep + 'js' + sep + 'linkHelper');
  var timeTransform = require(linkHelper.getJs("timeTransform.js"));
  var BootsrapSlider = require(linkHelper.getAbsolute('vendor', 'js', 'bootstrap-slider.min.js'));

  var firstEditPrev;
  var secondEditPrev;
  var $where = $(str$where);
  var $edits = $where.find('.textEdit.first,.textEdit.second');
  var $slide = $where.find('.slide');
  $slide.attr('data-max-value', max);
  $slide.attr('data-min-value', 0);
  $slide.attr('data-slider-step', step);
  $slide.attr('data-slider-value', '[' + 0 + ',' + max + ']');
  var slider = new BootsrapSlider(str$where + ' .slide', {
    tooltip: 'hide',
    max: max
  });

  this.init = function (first, second) {
    if (typeof first === 'undefined' && typeof second === 'undefined') {
      first = 0;
      second = max;
    }
    $edits.first().val(timeTransform.toStrFromSeconds(first));
    $edits.last().val(timeTransform.toStrFromSeconds(second));
    firstEditPrev = $edits.first().val();
    secondEditPrev = $edits.last().val();
  };
  this.setValue = function (arr, param1, param2) {
    slider.setValue(arr, param1, param2);
  };
  this.getValue = function () {
    return slider.getValue();
  };

  var initFunc = this.init;
  initFunc(min, max);
  this.onChangeFunc = function (newV, oldV) {
    if (newV[0] !== oldV[0] || newV[1] !== oldV[1]) {
      if (Math.abs(newV[1] - newV[0]) <= 1) {
        if (newV[0] !== oldV[0]) {
          newV[0] = Math.round(newV[1] - 1);
        } else {
          newV[1] = Math.round(newV[0] + 1);
        }
      }
      slider.setValue([newV[0], newV[1]]);
      initFunc(newV[0], newV[1]);
    }
  };

  //var onChangeFunc
  if (!onChange)onChange = this.onChangeFunc;
  slider.on('change', function (arr) {
    var oldV = arr.oldValue;
    var newV = arr.newValue;
    onChange(newV, oldV);
  });

  function validaedNumber(num, elseNum) {
    var n = parseInt(num);
    if (isNaN(n) || n < 0 || n >= 60) return elseNum;
    return Math.abs(n);
  }

  $edits.on('blur', function () {
    //blur = true;
    var str = $(this).val();
    var firstOrNot = $(this).hasClass('first');
    var oldStr = firstOrNot ? firstEditPrev : secondEditPrev;
    var newArr = timeTransform.getThreeStrs(str);
    var oldArr = timeTransform.getThreeStrs(oldStr);
    var out = [];
    for (var i = 0; i < oldArr.length; ++i) {
      out.push(validaedNumber(newArr[i], oldArr[i]));
    }
    var newTime = timeTransform.toSeconds(out[0], out[1], out[2]);
    if (newTime > max || newTime < min) {
      out = [];
      for (var j = 0; j < oldArr.length; ++j) {
        out.push(parseInt(oldArr[j]));
      }
    }
    var fullOut = timeTransform.toStr(out[0], out[1], out[2]);

    if (fullOut != oldStr) {

      if (firstOrNot) {
        if (slider.getValue()[1] > timeTransform.toSeconds(out[0], out[1], out[2])) {
          $(this).val(fullOut);
          slider.setValue(
            [timeTransform.toSeconds(out[0], out[1], out[2]), slider.getValue()[1]], false, false);
        } else {
          $(this).val(oldStr);
          $edits.last().val(fullOut);
          slider.setValue(
            [slider.getValue()[0], timeTransform.toSeconds(out[0], out[1], out[2])], false, false);
        }
      } else {
        if (slider.getValue()[0] < timeTransform.toSeconds(out[0], out[1], out[2])) {
          $(this).val(fullOut);
          slider.setValue(
            [slider.getValue()[0], timeTransform.toSeconds(out[0], out[1], out[2])], false, false);
        } else {
          $(this).val(oldStr);
          $edits.first().val(fullOut);
          slider.setValue(
            [timeTransform.toSeconds(out[0], out[1], out[2]), slider.getValue()[1]], false, false);
        }
      }
    }
  });
}
module.exports = Slider;
