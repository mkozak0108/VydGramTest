"use strict";

function linkHelper() {
  var fs = require('fs');
  var path = require('path');
  var sep = path.sep;
  var app = require('../' + sep + 'js' + sep + 'app.js');
  var mainPath = app.mainPath;

  function checkArguments() {
    var res = '';
    if (arguments.length && arguments[0].length) {
      for (var i = 0; i < arguments[0].length - 1; ++i) {
        res += arguments[0][i] + sep;
      }
      res += arguments[0][arguments[0].length - 1];
    }
    return res;
  }

  linkHelper.getJs = function () {
    return '..' + sep + 'js' + sep + checkArguments(arguments);
  };
  linkHelper.getCss = function () {
    return '..' + sep + 'css' + sep + checkArguments(arguments);
  };
  linkHelper.getAbsolute = function () {
    return '..' + sep + checkArguments(arguments);
  };
  linkHelper.getAbsoluteLong = function () {
    //console.log(mainPath + sep + checkArguments(arguments));
    return mainPath + sep + checkArguments(arguments);
  };
  linkHelper.getVendorJs = function () {
    return linkHelper.getAbsoluteLong('vendor' + sep + 'js' + sep + checkArguments(arguments));
  };
  linkHelper.getVendorCss = function () {
    return linkHelper.getAbsoluteLong('vendor' + sep + 'css' + sep + checkArguments(arguments));
  };
  linkHelper.getFolder = function (dir) {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir);
    }
    return dir;
  };
  linkHelper.getTempPath = function () {
    return this.getFolder(this.getAbsoluteLong('temp'));
  };

}
linkHelper();
module.exports = linkHelper;