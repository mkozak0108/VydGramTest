"use strict";

var http = require('https');
//var getMac = require('getmac');
var app = require('../js/app.js');
var path1 = require('path');
var fs = require('fs');
var serialNumber = require('serial-number');
serialNumber.preferUUID = true;

var host = 'https://members.explaindio.com/account';//'http://localhost:8888'

var Amember = function (host, port, developmentLicenseKey) {
  this.port = port || 80;
  this.devLicenseKey = developmentLicenseKey;
  this.host = host;
  this.lastCheckLicenseDate = '';//should to be saved for a long term
  this.productLicenseicenseKey = '';
  this.macAddress = '';
  this.showMessege = '';
  this.loadStartPage = '';
  this.loadOfflinePage = '';
  this.loadLogInPage = '';

  this.getLicenseKey = function () {
    //Here must be input of license key,
    // and saving them somewhere for long term
    //return 'CRTHF2QCJ6'; //for testing
    return '94ZFEAUR6Q';
  };
  this.getOptions = function (path) {
    return {
      'hostname': this.host,
      //'port': this.port,
      'path': path
    };
  };

  this.logIn = function (licenseKey, lastCheckDate, showMessage, loadStartPage, loadOfflinePage, loadLogInPage, isOnline) {
    this.loadStartPage = loadStartPage;
    this.loadOfflinePage = loadOfflinePage;
    this.showMessage = showMessage;
    this.lastCheckLicenseDate = lastCheckDate;
    this.loadLogInPage = loadLogInPage;
    this.checkUserSubscription(licenseKey);
    this.isOnline = isOnline;
    return '--';
  };

  this.processConnectionError = function (e) {
      var now = new Date();
      var sevenDays = 7 * 24 * 3600 * 1000;
      console.log(this.lastCheckLicenseDate);
      if (this.licenseKey !== '' && this.lastCheckLicenseDate !== '') {
        //Have never chack activation
        console.log(this);
        if ((+now - +this.lastCheckLicenseDate) >= sevenDays) {
          //user is offline and available 7 days term has gone
          console.log('offline, 7 days expired');
          //-------------------------------------------------------------
          console.log(this);
          var message = 'Sorry, but you should be online to use our ' +
            'app again. Please connect to the Internet and run app again.';
          if (this.showMessage !== '') {
            this.showMessage(message);
          }
        } else {
          console.log('offline, but still can use program');
          //console.log(+now - +this.lastCheckLicenseDate, sevenDays);
          //user is offline, but it have several days to use program
          if (this.loadStartPage !== '') {
            this.loadStartPage();
          }
        }
      } else {
        console.log('We must load login page.');
        this.loadLogInPage();
      }
  };

  this.checkUserSubscription = function (licenseKey) {
    //getMac.getMac((function (err, macAddress) {
    //  if (err) {
    //    throw err;
    //    var message = 'Sorry but we cannot get your MAC address to check license.';
    //    this.showMessage(message);
    //  } else {
    //    this.macAddress = macAddress;
    //    this.checkLicenseKey(this.checkActivation, licenseKey, macAddress);
    //  }
    //}).bind(this));
    serialNumber((function (err, uuid) {
        if (err) {
          throw err;
          console.log(err);
          var message = 'Sorry but we cannot get your UUID address to check license.';
          this.showMessage(message);
        } else {
          this.macAddress = uuid;
          console.log('Serial number: ' + uuid);
          this.checkLicenseKey(this.checkActivation, licenseKey, uuid);
        }
    }).bind(this));
  };

  this.checkLicenseKey = function (checkActivation, licenseKey, macAddress) {
    var path = '/softsale/api/check-license?key=' + licenseKey;
    var options = this.getOptions(path);
    try {
      var req = http.get(host + path, (function (res) {
        res.setEncoding('utf8');
        res.on('data', (function (resData) {
          console.log(resData);
          var jsonResData = JSON.parse(resData);
          if (jsonResData.code === 'license_not_found') {
            //Show massege that license key is not founds
            var message = 'Sorry but such license key is not found. Please check it.';
            this.showMessage(message);
          } else if (jsonResData.code === 'license_expired') {
            //Show massege that license key is expired
            var message = 'License key has expired. Please renew license.';
            this.showMessage(message);
          } else {
            var licenseTitle = jsonResData.scheme_title;
            console.log();
            if(licenseTitle === 'VydeoGram Standard' || licenseTitle === 'VydeoGram PRO') {
              this.productLicenseicenseKey = licenseKey;
              checkActivation.call(this, macAddress);
            } else {
              var message = 'The license key for this app is incorrect!';
              this.showMessage(message);
            }
          }
        }).bind(this));
      }).bind(this));
      req.on('error', (function (e) {
        //processing error
        this.processConnectionError(e);
      }).bind(this));
    } catch (err) {
      console.log(err);
      this.showMessage(err.message);
      if (err.message === 'Request path contains unescaped characters.') {
        this.showMessage('License key contains extra characters.');
      } else {
        this.showMessage(err.message);
      }
    }
  };

  this.checkActivation = function (macAddress) {
    var path = '/softsale/api/activate?key=' +
      this.productLicenseicenseKey + '&request[hardware-id]=' + macAddress;
    var options = this.getOptions(path);
    var req = http.get(host + path, (function (res) {
      res.setEncoding('utf8');
      res.on('data', (function (resData) {
        var jsonResData = JSON.parse(resData);
        if (jsonResData.code === 'no_spare_activations') {
          //Here should be shown messege that available 2 (or 12)
          //activations are in use, plese deactivate one of them
          //We maust show button "Renew subscription"
          var message = 'Sorry, but available activations for this ' +
            'license key is in use. You should deactivate it on one of two devices.';
          this.showMessage(message);//---------------------------------------

        } else if (jsonResData.code === 'ok') {
            this.lastCheckLicenseDate = new Date();
            this.macAddress = macAddress;
            console.log('Subscription is active. We should give' +
              ' this user access to work with application');
            if (this.loadStartPage !== '') {
              this.loadStartPage();
              this.updateLicense();
            }

          //this.diactivateLicense();//------------------------------
        } else if (jsonResData.code === 'license_disabled') {
          var message = 'Sorry, but this License Key is disabled.'
          this.showMessage(message);//---------------------------------------
        } else if (jsonResData.code === 'license_empty') {
          var message = 'License product key cannot be empty.';
          this.showMessage(message);
        } else {
          var message = 'There is some error occur.';
          this.showMessage(message);//---------------------------------------

          console.log(jsonResData);
        }
      }).bind(this));
    }).bind(this));
    req.on('error', (function (e) {
      console.log('Error with activation response', e);
      this.processConnectionError(e);
    }).bind(this));
  };

  this.deactivateLicense = function (win, loadLoagInPage) {
    var productLicenseKey = this.productLicenseicenseKey;
    var macAddress = this.macAddress;
    if (productLicenseKey !== '' && macAddress !== '') {
      var path = '/softsale/api/deactivate?key=' +
        productLicenseKey + '&request[hardware-id]=' + macAddress;
      var options = this.getOptions(path);
      var req = http.get(host + path, (function (res) {
        res.setEncoding('utf8');
        res.on('data', (function (resData) {
          var jsonResData = JSON.parse(resData);
          if (jsonResData.code === 'ok') {
            console.log('License key was deactivated' +
              ' for this software');
            var msg = 'License was successfully deactivated!';
            win.executeJavaScript('resetQuit();');
            this.resetLicense();
            loadLoagInPage();
            win.executeJavaScript('message(\'' + msg + '\', \'success\');');
          } else {
            var msg;
            if (jsonResData.message == 'Sorry, license re-activation limit reached') {
              msg = 'Sorry, license key re-activation limit has been reached.';
            } else {
              msg = jsonResData.message;
            }
            console.log(jsonResData.message);
            console.log(jsonResData);
            win.executeJavaScript('message(\'' + msg + '\', \'error\');');
          }
        }).bind(this));
      }).bind(this));
      req.on('error', (function (e) {
        console.log('Error with deactivation response', e);
        var msg = 'There aren\'t connection to the server now. Please try later!';
        win.executeJavaScript('message(\'' + msg + '\', \'error\');');
        //this.processConnectionError(e);
      }).bind(this));
    } else {
      var msg = 'No license key has entered yet.'
      win.executeJavaScript('message(\'' + msg + '\', \'error\');');
      console.log('There are no MAC address or productLicenseKey yet.');
    }
  };

  this.updateLicense = function () {
    var today = new Date();
    var mainPath = app.mainPath;
    var pathToLicense = path1.join(mainPath, 'license', 'license.json');
    var license = {
      'license': this.productLicenseicenseKey,
      'lastCheckDate': today
    };
    console.log(pathToLicense, '---');
    var text = JSON.stringify(license);
    fs.writeFile(pathToLicense, text, function (err) {
      if (err) {
        return console.log(err);
      }
      console.log("The file was saved!");
    });
  }

  this.resetLicense = function () {
    var mainPath = app.mainPath;
    var pathToLicense = path1.join(mainPath, 'license', 'license.json');
    var license = {
      "license": "",
      "lastCheckDate": ""
    };
    console.log(pathToLicense, '---');
    var text = JSON.stringify(license);
    fs.writeFile(pathToLicense, text, function (err) {
      if (err) {
        return console.log(err);
      }
      console.log("The file was saved!");
    });
  }

};

//var host = 'members.explaindio.com/account';//'localhost';
console.log(host);
var port = '';//'8888';//443;
var devLicense = 'Ardkt96nyECGIhs0z6VD';

var member = new Amember(host, port, devLicense);

module.exports = member;
