"use strict";

/**
 * @param cbAll - function(outArr)
 */
module.exports = function (cbAll,onProgress) {
  var fs = require('fs');
  var path = require('path');
  var sep = path.sep;
  var linkHelper = require('..' + sep + 'js' + sep + 'linkHelper');
  var app = require(linkHelper.getJs('app.js'));
  var util = require('util');
  var rnd = require(linkHelper.getJs('myRandom.js'));

  var MAX_STEAM = 1;
  var FORMAT = 'png';
  var NUM_OF_SCREENS = 4;
  var CEL_COUNT = 2;

  var ROW_COUNT = 2;
  var SMALL_IMG_SIZE = new Image(137, 77);
  //275,154  SMALL_IMG_SIZE.height*ROW_COUNT+ROW_COUNT-1
  var BIG_IMG_SIZE = new Image(SMALL_IMG_SIZE.width * CEL_COUNT + CEL_COUNT - 1, 154);
  var CANVAS_WIDTH_HEIGHT = new Image(BIG_IMG_SIZE.width + 2,
    (SMALL_IMG_SIZE.height + 1) * ROW_COUNT + BIG_IMG_SIZE.height + 2);

  function getName(val) {
    return val.substring(val.lastIndexOf('/') + 1, val.length)
  }

  function filt(val) {
    var name = getName(val);
    return name.indexOf('screen') !== -1;
  }

  function getImegForAllGif(index, imgs, forGifSrc, callback, outputFormat) {
    var canvas = document.createElement('CANVAS');
    var ctx = canvas.getContext('2d');
    canvas.width = CANVAS_WIDTH_HEIGHT.width;
    canvas.height = CANVAS_WIDTH_HEIGHT.height;
    ctx.fillStyle = '#767a86';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    //$('.buttons').after(canvas);

    var img = new Image(BIG_IMG_SIZE.width, BIG_IMG_SIZE.height);
    img.onload = function () {
      ctx.drawImage(img, 1, 1, img.width, img.height);
      var wid = 1;//width
      var hei = img.height + 2;//height
      for (var row = 0; row < ROW_COUNT; ++row) {
        wid = 1;
        for (var cel = 0; cel < CEL_COUNT; ++cel) {
          var num = row * CEL_COUNT + cel;
          ctx.drawImage(imgs[num], wid, hei, imgs[num].width, imgs[num].height);
          wid += imgs[0].width + 1;
        }
        hei += imgs[0].height + 1;
      }
      var dataURL = canvas.toDataURL(outputFormat || 'image/' + FORMAT);
      //console.log("--------------------------------");
      console.log(util.inspect(process.memoryUsage()));
      ctx = null;
      canvas = null;
      img = null;
      require('remote').getCurrentWindow().webContents.session.clearCache(function(){
        require('remote').getCurrentWindow().webContents.session.clearStorageData(function(){
          require('remote').getCurrentWindow().webContents.session.clearCache(function(){
            callback(index, dataURL);
            dataURL = null;
          });
        });
      });
      //console.log(util.inspect(process.memoryUsage()));
    };
    //$.get(forGifSrc,function(d){
      //console.log(d);
      //img.src = d;
    //});
    img.src = forGifSrc;
    forGifSrc = null;

  }

  var arr = app.garbage.filter(filt);
  var imgs = [];

  function fillImgs(index, callback) {
    imgs.push(new Image(SMALL_IMG_SIZE.width, SMALL_IMG_SIZE.height));
    var last = imgs.length - 1;
    imgs[last].onload = function () {
      ++index;
      if (index < NUM_OF_SCREENS) {
        fillImgs(index, callback);
      } else {
        callback();
      }
    };
    imgs[last].src = arr[index];
  }

  fillImgs(0, function () {
    var gifImgs = app.screens;
    var outArr = [];
    var lengthIndex = 0;

    function cbCreate(index, dataURL) {
      --index;
      ++lengthIndex;
      var name = 'forSave_' + lengthIndex + "." + FORMAT;
      var dir = linkHelper.getTempPath() + sep + name;
      var dir2 = app.appDataPrNameDir + sep + name;
      app.addToDelete(dir);
      var base64Data = dataURL.replace(/^data:image\/png;base64,/, "");
      dataURL = null;
      fs.writeFile(dir, base64Data, 'base64', function (err) {
        if (err) {
          message(err, 'error');
          console.log(err);
        }
        outArr.push(dir);
        fs.writeFile(dir2, base64Data, 'base64', function (err) {
          if (lengthIndex < gifImgs.length) {
            base64Data = null;
            run(index);
          } else {
            gifImgs = null;
            imgs = null;
            cbAll(outArr)
          }
        });
      });
    }

    function run(index) {
      if (index >= 0 && index < MAX_STEAM) {

        ++index;
        var src = gifImgs[lengthIndex].name;
        //getImegForAllGif(index, imgs, forGifSrc, callback, outputFormat)
        getImegForAllGif(index, imgs, src, cbCreate);
        run(index);
        src = null;
      }
    }

    run(0)
  });
};