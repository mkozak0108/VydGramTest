/**
 * Created by petropavlenko on 9/17/15.
 */
"use strict";

function gifHelp() {
  var gifshot = require('gifshot');
  /**
   * @param width - Desired width of the image : 200
   * @param height - Desired height of the image : 200
   * @param quality - quality = [1,20]
   * @param images - ['../temp/foto_1.jpg', '../temp/foto_2.jpg', '../temp/foto_3.jpg']
   * @param progressCallback -  function(captureProgress) {console.log(captureProgress)}
   * Callback function that provides the current progress of the current image
   * captureProgress : 0.1 or 0.333333333 or 0.4 or 1
   * @param interval -  0.5 the amount of time (in seconds) to wait between each frame capture
   * @param cb - cb(imageOut)
   */
  gifHelp.createGIF = function(width, height, quality, images, progressCallback, interval, cb) {
      //TODO: add check exist fotos
    try {
      gifshot.createGIF({
        'gifWidth': width,
        'gifHeight': height,
        'images': images,
        'progressCallback': progressCallback,
        'interval': interval
      }, function(obj) {
        if(!obj.error) {
          if(cb)cb(obj.image);
        } else {
          throw new Error('ERROR ' + obj.errorCode + " msg: " + obj.errorMsg);
        }
        if(obj.error){
          message(err.message, 'error');
        }
      });
    } catch(err) {
      message(err.message, 'error');
    }
  };
}
gifHelp();
module.exports = gifHelp;