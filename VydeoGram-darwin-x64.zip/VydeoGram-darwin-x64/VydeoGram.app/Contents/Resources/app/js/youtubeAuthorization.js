'use strict';

var https = require('https');
var google = require('googleapis');
var express = require('express');
var path = require('path');
var fs = require('fs');
var urlModule = require('url');
require('buffer');
var mime = require('mime');
var request = require('request');

var YOUTUBE_CLIENT_ID = '266734719131-4a268tasb07i36vlicnr4nptcg6bbnus.apps.' +
  'googleusercontent.com';
var YOUTUBE_CLIENT_SECRET = 'Bzhq1m2WR0L6UsYXJA5DKmwV';

var mainPath = __dirname.substring(0, __dirname.lastIndexOf('js') - 1);
var pathToTokens = mainPath + '/json/credentials.json';



var REDIRECT_URL = 'http://localhost:4000';

var OAuth2 = google.auth.OAuth2;
var oauth2Client = new OAuth2(YOUTUBE_CLIENT_ID, YOUTUBE_CLIENT_SECRET,
 REDIRECT_URL);

var scopes = [
  'https://www.googleapis.com/auth/youtube',
  'https://www.googleapis.com/auth/youtube.upload',
  'https://www.googleapis.com/auth/plus.login'
];


var Youtube = function (mainWindow, createGoogleWindow) {


  this.isAuthorized = false;
  this.authorizationCallback = undefined;
  var stringTokens = fs.readFileSync(pathToTokens, 'utf-8');
  this.tokens = (stringTokens == '') ? stringTokens : JSON.parse(stringTokens);
  this.callBackParams = '';
  this.window = mainWindow;
  this.createGoogleWindow = createGoogleWindow;

  this.authorize = function(resOkFileName, resBadFileName, authorizationCallback, callbackParams) {
    this.authorizationCallback = authorizationCallback;
    this.callbackParams = callbackParams;
    var url = oauth2Client.generateAuthUrl({
      access_type: 'offline',// 'online' or 'offline' (gets refresh_token)
      scope: scopes // If you only need one scope you can pass it as string
    });

    var app = express();

    app.get('/', (function (req, res) {
      var errorCode = req.query.error;
      if (errorCode === 'access_denied') {
        var resBadPathName = path.join(mainPath, 'views' , resOkFileName + '.html');
        fs.readFile(resBadPathName, 'utf8', function (err, data) {
          if (err) throw err;
          //console.log(data);
          res.send(data);
        });

      } else {
        //res.send('Congratulations! Now you can interact with YouTube' +
          //' using our application.');

        var resOkPathName = path.join(mainPath, 'views' , resOkFileName + '.html');
          fs.readFile(resOkPathName, 'utf8', function (err, data) {
            if (err) throw err;
            //console.log(data);
            res.send(data);
          });

        var code = req.query.code;
        //console.log(code);
        this.getTokens(code);
      }
      //app.close();

    }).bind(this));


    var server = app.listen(4000, (function () {
      //open(url);

      var parsedUrl = urlModule.parse(url);
      console.log(parsedUrl.host, parsedUrl.path);

      var options = {
        hostname: parsedUrl.host,
        path: parsedUrl.path,
        method: 'GET'
      };

      var req = https.request(options, (function(res) {
        //console.log("statusCode: ", res.statusCode);
        //console.log("headers: ", res.headers);
        console.log(this.createGoogleWindow);
        this.createGoogleWindow(url);
      }).bind(this));

      req.end();

      req.on('error', (function(e) {
        console.error(e);
        this.window.executeJavaScript("alert('Sorry, but you need access to Internet to upload video to YouTube')");//----------
        server.close();
      }).bind(this));
    }).bind(this));

  };

  this.getTokens = function (authorizationCode) {
    var code = authorizationCode;
    oauth2Client.getToken(code, (function(err, tokens) {
      // Now tokens contains an access_token and an optional refresh_token.
      if(!err) {
        this.tokens = tokens;
        oauth2Client.setCredentials(tokens);
        google.options({ auth: oauth2Client });
        try{
          this.saveTokens(JSON.stringify(tokens));
        } catch (e) {
          console.log(e);//0---------------
        }
        this.isAuthorized = true;
        this.authorizationCallback.apply(this, this.callbackParams);
        //console.log(this.callbackParams);
        //this.getUserName(function (name) {console.log(name);});
        //this.uploadVideo('concat.mp4');
      } else {
        console.log(err);
      }
    }).bind(this));
  };

  this.getUserName = function (processingName) {
    if (this.isAuthorized === true) {
      this._getUserName(processingName);
    } else {
      this.authorize(function () {
        this.getUserName(processingName);
      });
    }
  };

  this._getUserName = function (processingName) {
    var plus = google.plus('v1');
    plus.people.get({ userId: 'me', auth: oauth2Client },
       function(err, response) {
        // handle err and response
        var name = '';
        if(!err) {
          name = response.displayName;
        } else {
          console.log(err);
        }
        processingName(name);
      });
  };

  this.uploadVideo = function(videoName, processProgress, onSuccess) {
    this.secureExecute(this._uploadVideo, [videoName, processProgress, onSuccess])
  };

  this._uploadVideo = function(videoName, processProgress, onSuccess) {

    var expireDate = new Date(+this.tokens.expiry_date);
    console.log('---', expireDate, '---');
    var onSuccess = onSuccess;

    var mainPath = __dirname.substring(0, __dirname.lastIndexOf('js') - 1);
    console.log(mainPath);
    var videoFilePath = videoName;
    console.log(videoFilePath);
    var metadata = {snippet: { title: 'New Upload', description: 'Uploaded with ResumableUpload' },
      status: { privacyStatus: 'private' }};

    //-----------------------------body we need to get from web form----------
    var body = {
      "snippet": {
        "title": "My video title",
        "description": "This is a description of my video",
        "tags": ["cool", "video", "more keywords"],
        "categoryId": 22
      },
      "status": {
        "privacyStatus": "public",
        "embeddable": 'True',
        "license": "youtube"
      }
    };
    //------------------------------------------------------------------------
    console.log(videoFilePath);
    var options = {
      hostname: 'www.googleapis.com',
      //port: 80,
      path: '/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status,contentDetails',
      method: 'POST',
      headers: {
        "Host": "www.googleapis.com",
        "Authorization": "Bearer " + this.tokens['access_token'],
        "Content-Type": "application/json; charset=utf-8",
        "Content-Length": new Buffer(JSON.stringify(metadata)).length,
        "X-Upload-Content-Type": mime.lookup(videoFilePath),
        "X-Upload-Content-Length": fs.statSync(videoFilePath).size
      }
    };

    //console.log(options);
    var req = https.request(options, (function(res) {
      console.log("statusCode: ", res.statusCode);
      console.log("headers: ", res.headers);
      if (res.statusCode == 200) {
        var location = res.headers.location;
        console.log('---- ', location, ' -----');
        console.log(onSuccess);
          this.sendVideoToLocation(location, videoFilePath, 0, onSuccess);
          this.interval = setInterval(this.checkProgress.bind(this, location, videoFilePath, processProgress), 10000);

      } else {
        this.window.executeJavaScript("alert('Sorry, but there is some error occurred. Please try later!')");//-----
      }
      res.on('data', function(data) {

        console.log(data.toString());//---------------------It defines that error.
      });
    }).bind(this));

    req.write(JSON.stringify(metadata));

    req.end();

    req.on('error', function(e) {
      console.error(e);//---------------------------------
    });




  };

  this.sendVideoToLocation = function(location, pathToVideo, bytesUploaded, onSuccess) {
    console.log(location, pathToVideo);
    var videoSize = fs.statSync(pathToVideo).size;
    var onSuccess = onSuccess;
    var options = {
      url: location, //self.location becomes the Google-provided URL to PUT to
      headers: {
        'Authorization':	'Bearer ' + this.tokens.access_token,
        'Content-Length':	videoSize - bytesUploaded,
        'Content-Type':	mime.lookup(pathToVideo)
      }
    };

    try {
      //creates file stream, pipes it to self.location
      var uploadPipe = fs.createReadStream(pathToVideo, {
        start: bytesUploaded,
        end: videoSize
      });
    } catch (e) {
      console.log(e, 'str265');//------------------------------------
      return;
    }

    uploadPipe.pipe(request.put(options, (function(error, response, body) {
      if (!error) {
        //console.log(this);
        console.log('Video was successfully uploaded to YouTube!');//----------------
        //console.log(onSuccess);
        onSuccess();
        clearInterval(this.interval);
      }
      else {
        console.log(error, 'str277');//---------------We need to retry!-----------
        //this.resumeUpload(location, pathToVideo, onSuccess);
        //console.log(this);
        clearInterval(this.interval);
      }
    }).bind(this)));


  }

  this.saveTokens = function (tokens) {
    var mainPath = __dirname.substring(0, __dirname.lastIndexOf('js') - 1);
    fs.writeFile(mainPath + '/json/credentials.json', tokens, function (err) {
      if (err) {
        throw err;
      }
      console.log('It\'s saved!');
    });
  }

  this.secureExecute = function (callback, params) {
    if (this.tokens == '') {
      this.authorize('youtubeConfirm', 'youtubeDenied', callback, params);
      return;
    }

    var today = new Date();
    if (this.tokens.expiry_date - +(today) <  30000) {
      oauth2Client.setCredentials(this.tokens);
      //google.options({ auth: oauth2Client });
      oauth2Client.refreshAccessToken((function(err, tokens) {
        this.tokens = tokens;
        callback.apply(this, params);
        try{
          this.saveTokens(JSON.stringify(tokens));
        } catch (e) {
          console.log(e);//---------------
        }
      }).bind(this));

    } else {
      callback.apply(this, params);
    }
  }

  this.checkProgress = function (location, filePath, processProgress) {
    var videoSize = fs.statSync(filePath).size;
    var options = {
      url: location,
      headers: {
        'Authorization':	'Bearer ' + this.tokens.access_token,//--------------
        'Content-Length':	0,
        'Content-Range':	'bytes */' + videoSize
      }
    };
    request.put(options, function (err, res, body) {
      if (!err && typeof res.headers.range !== 'undefined') {
        var bytesUploaded = +(res.headers.range.substring(8));
        console.log(bytesUploaded);
        processProgress(bytesUploaded, videoSize);
      } else {
        console.log(err, '335str');
      }
    });

  };

  this.resumeUpload = function (location, pathToVideo, onSuccess) {
    this.checkProgress(location, pathToVideo, function(bytesUploaded, videoSize) {
      this.sendVideoToLocation(location, pathToVideo, bytesUploaded, onSuccess);
    }, onSuccess);
  }

};

//var youtube = new Youtube();

module.exports = Youtube;



