"use strict";

var path = require('path');
var sep = path.sep;
var app = require('../js/app.js');

//dAndD(file);

/**
 *
 * @param htmlMsg
 * @param type
 * @param [dialogType] - {name:'messageYesNo',yesFunc:function(){},noFunc:function(){}} or
 * {name: 'message',  close: function(){...}  }
 */
function message(htmlMsg, type, dialogType) {
  var $messageField = $('#msg');

  function check(str) {
    return str == 'none' || str == '' || str == undefined;
  }

  function clearMsg($messageField) {
    $messageField.html('');
    $messageField.addClass('noMsg');
  }

  function loadHtmlMsg(className, dialogType) {
    $messageField.removeClass('noMsg');
    $messageField.html($('<div class="' + className + '">').load('msg.html', function () {
      $messageField.find('.font').html(htmlMsg);
      $messageField.find('.btn').on('click', function () {
        if (typeof dialogType == 'object' && typeof dialogType.close == 'function')dialogType.close();
        clearMsg($messageField);
      });
    }));
  }

  function bindFunc$messageBtnField($messageFieldBtn, func) {
    $messageFieldBtn.on('click', function () {
      func();
      clearMsg($messageField);
    });
  }

  function loadHtmlYesNo(className, config) {
    var yesFunc = config.yesFunc,
      noFunc = config.noFunc;
    $messageField.removeClass('noMsg');
    $messageField.html($('<div class="' + className + ' yesNo">').load('msgYesNo.html', function () {
      $messageField.find('.font').html(htmlMsg);
      bindFunc$messageBtnField($messageField.find('.yes'), yesFunc);
      bindFunc$messageBtnField($messageField.find('.no'), noFunc);
    }));
  }

  function bindIfElseInDialog(func, otherParams) {
    if (type == "error") {
      func("errorMessage", otherParams);
    } else if (type == "success") {
      func("successMessage", otherParams);
    } else if (type == "hint") {
      func("hintMessage", otherParams);
    } else clearMsg($messageField);
  }

  if (typeof type == 'string')
    type = type.toLowerCase();
  var dialogTypeName = "";
  if (typeof dialogType == 'object' && typeof dialogType.name == 'string')
    dialogTypeName = dialogType.name.toLowerCase();
  if (check(htmlMsg) || check(type)) clearMsg($messageField);
  else {
    if (check(dialogTypeName) || dialogTypeName == 'message') {
      bindIfElseInDialog(loadHtmlMsg, dialogType);
    } else if (dialogTypeName == 'messageyesno') {
      bindIfElseInDialog(loadHtmlYesNo, dialogType);
    } else clearMsg($messageField);
  }
}
window.onerror = function (errorMsg, url, lineNumber) {
  console.log(errorMsg);
  console.log(url);
  console.log(lineNumber);
  message("Error:" + errorMsg + "\n\nurl:" + url + '\n\nline: ' + lineNumber, 'error');
};

var forbiddenIcon = $('.forbidden-icon');
//console.log(forbiddenIcon);
forbiddenIcon.addClass('hide');

window.ondragover = function (event) {
  event.preventDefault();
  event.dataTransfer.dropEffect = 'none';
  event.dataTransfer.effectAllowed = 'none';
  var forbiddenIcon = $('.forbidden-icon');
  forbiddenIcon.removeClass('hide');
  forbiddenIcon.addClass('show');
  forbiddenIcon.offset({top: event.clientY - 40, left: event.clientX + 6});
};

$('.DAndDGrey').ondragover = function (event) {
  var forbiddenIcon = $('.forbidden-icon');
  forbiddenIcon.removeClass('show');
  forbiddenIcon.addClass('hide');
  console.log('');
};

$(document).mouseleave(function (event) {
  var forbiddenIcon = $('.forbidden-icon');
  forbiddenIcon.removeClass('show');
  forbiddenIcon.addClass('hide');
});

$(document).mouseup(function (e) {
  var forbiddenIcon = $('.forbidden-icon');
  forbiddenIcon.removeClass('show');
  forbiddenIcon.addClass('hide');
});

$('html').on("dragleave", function (e) {
  var forbiddenIcon = $('.forbidden-icon');
  forbiddenIcon.removeClass('show');
  forbiddenIcon.addClass('hide');
});

$(document).mouseenter(function (e) {
  $(document).mousedown();
});

//-------------------Modal window----------------------


  $('.btn-share').click( function(event){ // лoвим клик пo ссылки с id="go"
    event.preventDefault(); // выключaем стaндaртную рoль элементa
    $('#overlay').fadeIn(400, // снaчaлa плaвнo пoкaзывaем темную пoдлoжку
        function(){ // пoсле выпoлнения предъидущей aнимaции
          $('#modal_form')
              .css('display', 'block') // убирaем у мoдaльнoгo oкнa display: none;
              .animate({opacity: 1, top: '48px'}, 200); // плaвнo прибaвляем прoзрaчнoсть oднoвременнo сo съезжaнием вниз
        });
  });
  /* Зaкрытие мoдaльнoгo oкнa, тут делaем тo же сaмoе нo в oбрaтнoм пoрядке */
  $('#overlay').click( function() { // лoвим клик пo крестику или пoдлoжке
    $('#modal_form')
        .animate({opacity: 0, top: '48px'}, 200,  // плaвнo меняем прoзрaчнoсть нa 0 и oднoвременнo двигaем oкнo вверх
        function () { // пoсле aнимaции
          $(this).css('display', 'none'); // делaем ему display: none;
          $('#overlay').fadeOut(400); // скрывaем пoдлoжку
        }
    );
  });
  $('#overlay, #modal_close').click(function() {
    $('#modal_form2')
        .animate({opacity: 0, top: '48px'}, 200,  // плaвнo меняем прoзрaчнoсть нa 0 и oднoвременнo двигaем oкнo вверх
        function () { // пoсле aнимaции
          $(this).css('display', 'none'); // делaем ему display: none;
          //$('#overlay').fadeOut(400); // скрывaем пoдлoжку
        }
    );
  });


//Modal window 2

$('.btn-social').click( function(event){ // лoвим клик пo ссылки с id="go"
  event.preventDefault(); // выключaем стaндaртную рoль элементa
  $('#overlay').fadeIn(400, // снaчaлa плaвнo пoкaзывaем темную пoдлoжку
      function(){ // пoсле выпoлнения предъидущей aнимaции
        $('#modal_form2')
            .css('display', 'block') // убирaем у мoдaльнoгo oкнa display: none;
            .animate({opacity: 1, top: '48px'}, 200); // плaвнo прибaвляем прoзрaчнoсть oднoвременнo сo съезжaнием вниз
      });
});

function resetQuit() {
  app.clearTemp(function () {
    window.onbeforeunload = function(){}
  });
}

$('.deactivate').click(function (event) {
  var index = require('remote').require('./index.js');
  index.deactivateLicense();
});


//----------------------------------------------------

