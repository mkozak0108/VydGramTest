"use strict";

/**
 * @param inputPathName - videoInput
 * @param times - array [30.5, '50%', '01:10.123']
 * @param cb - onEnd  cb(namePaths) : namePaths - filenames screans
 * @param width - Desired width of the image : 200
 * @param height - Desired height of the image : 200
 * Callback function that provides the current progress of the current image
 * captureProgress : 0.1 or 0.333333333 or 0.4 or 1
 * @param quality - [1,12] , 1 is the best
 * @param selector$progressBarBox = '.progressBar'
 * @param cb - cb(imageOut)
 */
module.exports = function (inputPathName, times, width, height, quality, selector$progressBarBox, cb, backCb) {

  var path = require('path');
  var fs = require('fs');
  var sep = path.sep;
  var linkHelper = require('..' + sep + 'js' + sep + 'linkHelper');
  var getVidImgs = require(linkHelper.getJs('getVidImgs.js'));
  var gifHelp = require(linkHelper.getJs("gifHelp.js"));
  var ffmpegHelp = require(linkHelper.getJs("ffmpegHelp.js"));
  var app = require(linkHelper.getJs('app.js'));
  var ProgressBar = require('progressbar.js');
  var MyProjects = require(linkHelper.getJs('myProjects.js'));
  var mkdirp = require(linkHelper.getJs('mkdirp'));
  var fse = require('fs.extra');

  var circle;
  var $progressBarBox = $(selector$progressBarBox);

  app.appDataPrNameDir = MyProjects.getFolderName(app.uploadedFile.name);
  mkdirp(app.appDataPrNameDir);
  //window.hd = new memwatch.HeapDiff();
  $progressBarBox.html('');
  circle = new ProgressBar.Circle(selector$progressBarBox, {
    strokeWidth: 9,
    trailWidth: 9,
    duration: 270,
    text: {
      value: '0'
    },
    step: function (state, bar) {
      bar.setText((bar.value() * 100).toFixed(0) + "%");
    }
  });
  var plas = 0;
  var date = new Date();

  function onProgress(captureProgress) {
    captureProgress = captureProgress / 2;
    var procent = parseFloat((captureProgress).toFixed(4)) + plas;
    circle.animate(procent);
    console.log("pr: " + captureProgress);
  }

  function cbAll(imageOut) {
    app.imageOut = imageOut;
    app.imageOut = linkHelper.getTempPath() + sep + 'gif.gif';
    //var base64Data = app.imageOut.replace(/^data:image\/gif;base64,/, "");
    mkdirp(app.appDataPrNameDir);
    //fse.copy(app.imageOut, dir, {replace: true}, function (err) {
    //  $('.MyProjects').click();
    //});

    fse.copy(app.imageOut, app.appDataPrNameDir + sep + 'gif.gif', {replace: true}, function (err) {
      //fs.writeFile(linkHelper.getTempPath() + sep + 'gif.gif', base64Data, 'base64', function (err) {
      //  fs.writeFile(app.appDataPrNameDir + sep + 'gif.gif', base64Data, 'base64', function (err) {
      if (err) {
        console.log(err);
        message(JSON.stringify(err), 'error');
      }
      var json = {
        gifStart: app.startTime,
        gifEnd: app.endTime,
        gifDuration: app.gifDuration,
        prNameDir: app.appDataPrNameDir,
        videoFilePath: app.uploadedFile.path
      };
      fs.writeFile(app.appDataPrNameDir + sep + 'gif.json', JSON.stringify(json), 'utf-8', function (err) {

        $('.header .btn,.header .flex').css('display', '');
        if (cb)cb(imageOut);
      });
      //  });
      //});
    });
  }

  function VideoGramScreens(outArr) {
    console.log(outArr);
    circle.animate(0.5);
    console.log((new Date() - date) / 1000);
    date = new Date();
    plas = 0.5;

    var tempPath = linkHelper.getTempPath();
    var forSave = mkdirp.formPath(tempPath + sep + 'forSave_%d.png');
    var forSaveGif = mkdirp.formPath(tempPath + sep + 'gif.gif');
    ffmpegHelp.getGif(forSave, app.interval,
      forSaveGif, cbAll);
    //gifHelp.createGIF(width, height, quality, outArr, onProgress, app.interval, cbAll);
  }

  function screensMainCB(namePaths) {
    app.screens.length = 0;
    for (var i = 0; i < namePaths.length; ++i) {
      app.addToDelete(namePaths[i]);
      app.screens.push({name: namePaths[i], time: times[i]});
    }
    getVidImgs(VideoGramScreens);
  }

  var times2 = [];
  var duration = app.endTime - app.startTime;

  function partDuration(fractal, degits) {
    return parseFloat((app.startTime + (duration * fractal)).toFixed(degits));
  }

  function cbFourScreens() {
    ffmpegHelp.getScreens3(inputPathName, linkHelper.getTempPath() + sep + 'foto_%d.png', times, screensMainCB, onProgress);
  }

  times2.push(partDuration(0.333, 3));
  times2.push(partDuration(0.66, 3));
  times2.push(partDuration(0.9, 3));

  function cbGetScreens(filenames) {
    app.addToDelete(linkHelper.getTempPath() + sep + 'screen.png');
    for (var i = 0; i < filenames.length; ++i) {
      app.addToDelete(filenames[i]);
    }
    cbFourScreens();
  }

  $('.header .btn,.header .flex').css('display', 'none');
  ffmpegHelp.getScreen2(app.uploadedFile.path, app.startTime, linkHelper.getTempPath() + sep + 'screen.png',
    function () {
      ffmpegHelp.getScreens3(app.uploadedFile.path, linkHelper.getTempPath() + sep + 'screen_%d.png',
        times2, cbGetScreens);
    });

  //ffmpegHelp.getScreens(inputPathName, linkHelper.getTempPath(), 'foto_%i.png', times, cbScreens);
  //ffmpegHelp.getScreens2(inputPathName, times[0], 69, 0.175, linkHelper.getTempPath() + sep+'foto_%d.png', cbScreens);
};

//var session = require('remote'). getCurrentWindow(). webContents.session

//session.clearStorageData()

//session.clearCache()
