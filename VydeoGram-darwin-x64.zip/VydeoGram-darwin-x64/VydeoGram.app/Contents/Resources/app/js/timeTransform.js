"use strict";

var timeTransform = {
  toSeconds: function(hours, minutes, seconds, milliseconds) {
    var hoursTmp = parseInt(hours);
    var minutesTmp = parseInt(minutes);
    var secondsTmp = parseInt(seconds);
    if(parseInt(milliseconds) > 500)secondsTmp += 1;
    return (((hoursTmp * 60) + minutesTmp) * 60 ) + secondsTmp;
  },
  toSecondsFromStr: function(str) {
    var tempstr = str.substring(0, str.lastIndexOf("."));
    var arr = tempstr.split(':');
    return this.toSeconds(arr[0], arr[1], arr[2],
      str.substring(str.lastIndexOf('.') + 1, str.length));
  },
  toStr: function(hours, minutes, seconds) {
    hours = hours > 0 ? hours : 0;
    minutes = minutes > 0 ? minutes : 0;
    seconds = seconds > 0 ? seconds : 0;
    return (hours < 10 ? "0" + hours : hours) + ":" +
      (minutes < 10 ? "0" + minutes : minutes) + ":" +
      (seconds < 10 ? "0" + seconds : seconds);
  },
  toStrFromSeconds: function(seconds) {
    var totalSeconds = parseFloat(seconds);
    var hours = Math.floor(totalSeconds / 3600);
    totalSeconds %= 3600;
    var minutes = Math.floor(totalSeconds / 60);
    var secondsTmp = totalSeconds % 60;
    return this.toStr(hours, minutes, secondsTmp);
  },
  getThreeStrs: function(txt) {
    var arr = [];
    arr.push(txt.substring(0, txt.indexOf(':')));
    arr.push(txt.substring(txt.indexOf(':') + 1, txt.lastIndexOf(':')));
    arr.push(txt.substring(txt.lastIndexOf(':') + 1, txt.length));
    return arr;
  }
};
module.exports = timeTransform;