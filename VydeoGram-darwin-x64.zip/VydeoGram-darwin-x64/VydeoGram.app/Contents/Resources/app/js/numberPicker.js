/**
 * Created by petropavlenko on 9/15/15.
 */

/**
 * @param $numberPicker - just one $numberPicker
 * @param oldVal - string elseNumber (class doesn't use it always)
 * @param step (num * numberOfZero + step) / numberOfZero
 * @param numberOfZero  (num * numberOfZero + step) / numberOfZero
 * @param max
 * @param min
 * @param befChange
 * @param aftChange
 */
function numberPicker($numberPicker, oldVal, step, numberOfZero, max, min, befChange, aftChange) {
  function changeArith($where, arithmetic) {
    var $number = $where.closest('.numberPicker').find('.number');
    var str = $number.val();
    if (befChange)str = befChange(str);
    var num = parseFloat(str);
    if (!(isNaN(num))) {
      num = parseFloat(befChange(oldVal));
    }
    num = arithmetic(num);
    if (num >= min && num <= max) {
      init($number, num);
    } else {
      if (num >= max) {
        init($number, max);
      } else {
        init($number, min);
      }
    }
  }

  function init($number, num) {
    oldVal = num + "";
    var str = oldVal;
    if (befChange)str = befChange(str);
    if (aftChange)str = aftChange(str);
    oldVal = str;
    $number.val(oldVal);
  }

  $numberPicker.find('.up').click(function (e) {
    changeArith($(this), function (num) {
      return (num * numberOfZero + step) / numberOfZero;
    });
  });
  $numberPicker.find('.down').click(function (e) {
    changeArith($(this), function (num) {
      return (num * numberOfZero - step) / numberOfZero;
    });
  });
  $numberPicker.find('.number').on('blur', function () {
    var $number = $(this);
    var str = $number.val();
    if (befChange)str = befChange(str);
    var n = parseFloat(str);
    if (!(isNaN(n)) && n >= min && n <= max) {
      init($number, n);
    } else {
      if (n < min)
        init($number, min);
      else if (n > max)
        init($number, max);
      else
        init($number, oldVal);
    }
  });
}
module.exports = numberPicker;