"use strict";
function ffmpegHelp() {
  var fs = require('fs');
  var fluent_ffmpeg = require('fluent-ffmpeg');
  var ffmpegH = require('ffmpeg-static');
  var ffprobeH = require('ffprobe-static');
  var path = require('path');
  var spawn = require('child_process').spawn;
  var sep = path.sep;
  var linkHelper = require('..' + sep + 'js' + sep + 'linkHelper');
  var app = require(linkHelper.getJs('app.js'));
  var mkdirp = require(linkHelper.getJs('mkdirp'));
  var getVidImgs = require(linkHelper.getJs('getVidImgs.js'));

  fluent_ffmpeg.setFfmpegPath(ffmpegH.path);
  fluent_ffmpeg.setFfprobePath(ffprobeH.path);

  var MAX_STREAMS = 1;
  var PROGRESS_DURATION = 200;
  var PROGRESS_OUT_COUNT = 20;
  var SCREENS_PALETTE_LENGTH = 30;

  function doArg(data, cbs) {
    if (cbs.constructor === Array) {
      for (var i = 0; i < cbs.length; ++i) {
        cbs[i](data);
      }
    } else {
      cbs(data);
    }
  }

  function commandOnErr(command) {
    command
      .on('error', function (err, stdout, stderr) {
        message(stderr, 'error');
        console.log('inserting Cannot process video: ' + JSON.stringify(err) +
          "   stderr:" + JSON.stringify(stderr) + "   stdout:" + JSON.stringify(stdout));
      });
  }

  ffmpegHelp.getData = function (path) {
    var arr = arguments;
    fluent_ffmpeg.ffprobe(path, function (err, data) {
      try {
        if (arr.length < 2)console.log(data);
        else for (var i = 1; i < arr.length; ++i)  doArg(data, arr[i]);
      } catch (err) {
        console.log("error " + JSON.stringify(err));
      }
    });
  };

  /**
   * @param inputPathName
   * @param outputPath
   * @param outputName
   * @param time - time when to create screenshot
   * @param cb - function(outputName)
   */
  ffmpegHelp.getScreen = function (inputPathName, outputPath, outputName, time, cb) {
    var command = fluent_ffmpeg(inputPathName);
    commandOnErr(command);

    var namePaths;
    try {
      command.screenshots({
        timestamps: [time],
        filename: outputName,
        folder: outputPath
      })
        .on('filenames', function (filenames) {
          console.log('Will generate ' + filenames.join(', '));
          namePaths = filenames;
        })
        .on('end', function () {
          //command.stdin.pause();
          //command.kill();
          cb(path.join(outputPath, namePaths[0]));
          //command = null;
        });
    } catch (err) {
      message(err.message, 'error');
    }
  };
  /**
   * @param inputPathName - videoInput
   * @param outputPath folder - '/path/to/output'
   * @param fileName - 'thumbnail-at-%s-seconds.png'
   * @param time - array [30.5, '50%', '01:10.123']
   * @param cb - onEnd  cb(namePaths) : namePaths - filenames screans
   */
  ffmpegHelp.getScreens = function (inputPathName, outputPath, fileName, time, cb) {
    try {
      //app.width = 426;
      //app.heigth = 240;
      var command = fluent_ffmpeg();
      //command.seek(time[0]);
      command.addInput(inputPathName);
      commandOnErr(command);
      var namePaths;
      command
        .complexFilter('scale=' + app.width + "x" + app.heigth + ',setsar=1:1')
        .screenshots({
          timestamps: time,
          filename: fileName,
          folder: outputPath
        })
        .on('filenames', function (filenames) {
          console.log('Will generate ' + filenames.join(', '));
          namePaths = filenames;
        })
        .on('progress', function (progress) {
          console.log('Processing: ' + JSON.stringify(progress) + ' done');
        })
        .on('end', function () {
          var fileNames = [];
          for (var i = 0; i < namePaths.length; ++i) {
            fileNames.push(path.join(outputPath, namePaths[i]));
          }
          cb(fileNames);
        });
    } catch (err) {
      message(err.message, 'error');
    }
  };

  ffmpegHelp.commandFFMpeg = function (params, cb, cbParams) {
    //var time = new Date();
    var ffmpegProc = spawn(ffmpegH.path, params);
    //ffmpegProc.stderr.on('data', function(data) {
    //  console.log('stderr: ' + JSON.stringify(data));
    //});
    //ffmpegProc.stdout.on('data', function(data) {
    //  //console.log(new Date() - time);
    //  console.log(data);
    //});
    ffmpegProc.on('close', function (code) {
      console.log('child process exited with code ' + code);
      if (cb) {
        if (typeof cbParams !== "undefined")cb(cbParams);
        else cb();
      }
    });
  };

  /**
   *
   * @param input = "/Users/petropavlenko/Downloads/The Ultimate Fails Compilation ✔.mp4"
   * @param startTime = 00:18:01
   * @param screensNumber = 20
   * @param interval = 0.175
   * @param output = 'temp/out_%d.png'
   * @param cb = callback function()
   */
  ffmpegHelp.getScreens2 = function (input, startTime, screensNumber, interval, output, cb) {
    var fileNames;
    if (output.indexOf('%d') > -1) {
      fileNames = [];
      var strBef = output.substring(0, output.lastIndexOf('%d'));
      var strAft = output.substring(output.lastIndexOf('%d') + 2, output.length);
      for (var i = 1; i <= screensNumber; ++i) {
        fileNames.push(strBef + i + strAft);
      }
    }
    this.commandFFMpeg(['-ss', startTime + "", '-i', input, '-vf', 'fps=fps=1/1',
      "select=gt(scene\\," + interval + ")",
      '-frames:v', screensNumber + "", '-vsync', 'vfr', output], cb, fileNames);
  };

  /**
   * @param inputPathName - videoInput
   * @param output folder - '/path/to/output/'thumbnail-at-%s-seconds.png'
   * @param times - array [30.5, '50%', '01:10.123']
   * @param cb - onEnd  cb(namePaths) : namePaths - filenames screans
   * @param progressFunc - function percents
   */
  ffmpegHelp.getScreens3 = function (inputPathName, output, times, cb, progressFunc) {
    var fileNames;
    if (output.indexOf('%d') > -1) {
      fileNames = [];
      var dNum = output.lastIndexOf('%d');
      var strBef = output.substring(0, dNum);
      var strAft = output.substring(dNum + 2, output.length);
      for (var i = 1; i <= times.length; ++i) {
        fileNames.push(strBef + i + strAft);
      }
    }
    console.log(fileNames);
    var countIndex = 0;
    var procesIndex = 0;
    var progresCount = 0;

    var _onProgress;
    var out;
    if (progressFunc) {
      _onProgress = function () {
        if (countIndex < times.length) {
          progressFunc(countIndex / times.length);
          progresCount = 0;
          out = setTimeout(_onProgress, PROGRESS_DURATION);
        }
      };
      _onProgress();
    }

    function count(index) {
      if (countIndex < times.length - 1) {
        ++countIndex;
        //if(progressFunc)progressFunc(countIndex / times.length);
        if (index > 0)--index;
        if (progresCount >= PROGRESS_OUT_COUNT) {
          progresCount = 0;
          progressFunc(countIndex / times.length);
        } else {
          ++progresCount;
        }
        start(index);
      } else {
        if (out)clearTimeout(out);
        if (progressFunc)progressFunc(countIndex / times.length);
        cb(fileNames);
      }
    }

    function start(index) {
      if (index < MAX_STREAMS && procesIndex < times.length) {
        ffmpegHelp.getScreen2(inputPathName, times[procesIndex], fileNames[procesIndex], count, index);
        ++index;
        ++procesIndex;
        start(index);
      }
    }

    start(0);
  };
  /**
   * @param input = "/Users/petropavlenko/Downloads/The Ultimate Fails Compilation ✔.mp4"
   * @param time = 00:18:01
   * @param output = 'temp/out.png'
   * @param cb = callback function(cbParams)
   * @param cbParams = cb(cbParams)
   */
  ffmpegHelp.getScreen2 = function (input, time, output, cb, cbParams) {

    function doo() {
      ffmpegHelp.commandFFMpeg(['-ss', time, '-i', input, '-frames:v', '1', output], cb, cbParams);
    }

    if (fs.existsSync(output)) {
      fs.unlink(output, function (err) {
        if (err) {
          console.log('error while deleted: ' + output);
          console.log(err.message);
        } else doo();
      });
    } else {
      doo();
    }
  };

  ffmpegHelp.getDuration = function getDuration(data) {
    var str = data.streams[0].duration + "";
    var duration = '';
    if (str.indexOf('.') > -1) {
      duration = str.substring(0, str.lastIndexOf("."));
    } else {
      duration = str;
    }
    return parseFloat(duration);
  };

  ffmpegHelp.getTimes = function (start, end) {
    var videoDuration = end - start;
    var out = [];
    if (videoDuration < app.gifDuration) {
      out = ffmpegHelp.getTimes2(start, end);
      if (out[out.length - 1] > app.duration - 1)out.pop();
      return out;
    }
    var partsNum = Math.ceil(app.gifDuration / app.PRIORITY_SEGMENT_DURATION) - 1;
    if (((app.gifDuration / app.PRIORITY_SEGMENT_DURATION) + "").indexOf('.') < 0) {
      partsNum = app.gifDuration / app.PRIORITY_SEGMENT_DURATION;
    }
    if (partsNum <= 0)partsNum = 1;
    app.interval = 0.1;
    if (app.gifDuration / app.interval > app.MAX_SCREENS) {
      app.interval = app.gifDuration / app.MAX_SCREENS;
    }
    app.intervalIn = app.interval;

    var videoSegmentDuration = videoDuration / partsNum;
    var gifSegmentDuration = app.gifDuration / partsNum;
    var i;
    var durations = [];
    for (i = 0; i < partsNum; ++i) {
      var thisStart = start + videoSegmentDuration * i;
      durations.push(ffmpegHelp.getTimesPart(thisStart, thisStart + videoSegmentDuration, gifSegmentDuration));
    }
    out = durations.reduce(function (a, b) {
      return a.concat(b);
    }, []);
    if (out[out.length - 1] > app.duration - 1)out.pop();
    return out;
  };

  ffmpegHelp.getTimesPart = function (start, end, gifSegmentDuration) {
    var videoPartDuration = end - start;
    var partVideoHalfTime = start + videoPartDuration / 2;
    var partGifHalfTime = gifSegmentDuration / 2;
    var newStart, newEnd;
    newStart = partVideoHalfTime - partGifHalfTime;
    newEnd = partVideoHalfTime + partGifHalfTime;

    if (newStart < start) {
      console.log('bad sart ' + newStart + ' replace : ' + start);
      newStart = start;
    }
    if (newEnd > end) {
      console.log('bad sart ' + newEnd + ' replace : ' + start);
      newEnd = end;
    }

    return ffmpegHelp.getTimesSimple(newStart, newEnd, app.intervalIn);

    //var gifPartDuration =  ;

  };
  ffmpegHelp.getTimesSimple = function (start, end, interval) {
    var timesOut = [];
    interval = parseFloat(interval);
    for (var i = start; i <= end; i += interval) {
      timesOut.push(i)
    }
    //if (timesOut.length > 2)timesOut.pop();
    return timesOut;
  };
  ffmpegHelp.getTimes2 = function (start, end) {
    app.interval = 0.1;
    var screens = app.gifDuration / app.interval;
    if (screens > app.MAX_SCREENS) {
      app.interval = app.gifDuration / app.MAX_SCREENS;
      screens = app.MAX_SCREENS;
    }
    app.intervalIn = (end - start) / screens;

    //var timesOut = [];
    //app.intervalIn = parseFloat(app.intervalIn);
    //for (var i = start; i <= end; i += app.intervalIn) {
    //  timesOut.push(i)
    //}
    //if (timesOut.length > 2)timesOut.pop();
    return ffmpegHelp.getTimesSimple(start, end, app.intervalIn);
  };
  /**
   * @param screens = 'temp/forSave_%d.png'
   * @param delay
   * @param output
   * @param cb
   */
  ffmpegHelp.getGif = function (screens, delay, output, cb) {
    var time1 = new Date();
    var fps = (1 / parseFloat(delay)).toFixed(6);

    console.log("fps " + fps);
    linkHelper.getTempPath();
    var palettePathName = mkdirp.formPath(linkHelper.getTempPath() + sep + 'palette.png');
    ffmpegHelp.commandFFMpeg(['-i', screens, '-vf', "palettegen=stats_mode=full",
      '-y', palettePathName], function () {
      console.log(new Date() - time1 + "  palettegen");
      ffmpegHelp.commandFFMpeg(['-r', fps, '-i', screens, "-i", palettePathName,
        '-lavfi', 'paletteuse', '-y', output], function () {
        console.log(new Date() - time1 + "  gif created");
        if (cb)cb(output);
      });
    });
  };
}
ffmpegHelp();
module.exports = ffmpegHelp;

//"/Users/petropavlenko/Downloads/The Ultimate Fails Compilation ✔.mp4"

//-ss 00:18:01 -i "mp4" -frames:v 1 screenshot.png

//-ss 00:05:01 -i "mp4" -vf "select=gt(scene\,0.175)" -frames:v 20 -vsync vfr out%02d.png

//ffmpeg -i temp/forSave_%d.png -vf "palettegen=stats_mode=full" -y temp/palette.png
//ffmpeg -r 2 -i temp/forSave_%d.png -i temp/palette.png -lavfi "paletteuse" temp/gif.gif

//It is important to write cron function to clean/delete GIF images from account which expired 30 or more day ago.

//mp4 files that wont work are 1440p resolutions. Test on that resolution.  Also test on 4k resolution.
