"use strict";

module.exports = function videoGramPreview() {

  var fs = require('fs');
  var path = require('path');
  var sep = path.sep;
  var linkHelper = require('..' + sep + 'js' + sep + 'linkHelper');
  var app = require(linkHelper.getJs('app.js'));
  //var ffmpegHelp = require(linkHelper.getJs("ffmpegHelp.js"));
  //var GetVidHTML = require(linkHelper.getJs("getVidGramHTML.js"));
  var createGifFunc = require(linkHelper.getJs("createGifFunc.js"));
  var BackHelp = require(linkHelper.getJs('backHelp.js'));
  var convert = require(linkHelper.getJs('convert.js'));
  var MyProjects = require(linkHelper.getJs('myProjects.js'));
  var rnd = require(linkHelper.getJs('myRandom.js'));

  var $body = $('body');
  var $head = $('head');

  function clearCss($head) {
    $head.find('link')
      .not('link[href="../css/mainBtns.css"]')
      .not('link[href="../css/mainBack.css"]')
      .remove();
  }


  BackHelp.clear();
  var $btns;
  clearCss($head);
  $head.append('<link rel="stylesheet" href="../css/videoGramPreview.css"/>');
  $head.append('<link rel="stylesheet" href="../css/videoGram.css"/>');

  $body.find('.caption').text('videoGram Preview');
  $body.append($('<div>').load('videoGramPreview.html', function () {
    if(app.whereBackMyProjects == -1){
      var $mainMenu = $('.MainMenu');
      $mainMenu.off('click');
      MyProjects.myPrOrNotClick(false);
      $mainMenu.removeClass('pushed');
      $mainMenu.click(function () {
        require(linkHelper.getJs(app.back[0]))();
      });
    }
    app.whereBackMyProjects = 2;
    $btns = $body.find('.buttons');

    $btns.css('display', 'none');
    $body.find('.caption').after($('<div class="videoGramContainer">'));

    var img = new Image();
    $('.videoGramContainer').html(img);
    img.onload = function () {
      img.id = "imgPreview";
      $btns.css('display', '');
      $('.videoGramContainer').html(img);
      //--------------YouTube-------------------------
      var _pathToVideo = MyProjects.getJson(app.appDataPrNameDir);
      var pathToVideo = _pathToVideo.videoFilePath;
      console.log(pathToVideo);
      $('.youtube-btn').on('click', function (e) {
        function progressBar(percentages) {
          var bar = $('.progress-bar');
          bar.css('width', percentages + '%');
          if (percentages <= 6) {
            bar.text('');
          } else {
            bar.text(percentages + '%');
          }
        }

        var index = require('remote').require('./index.js');
        var processProgress = function (bytesUploaded, videoSize) {
          var percentages = (bytesUploaded / videoSize) * 100;
          console.log(percentages.toFixed(0) + '%');
        };

        var onSuccess = function () {
          progressBar(100);
          var bar = $('.progress-bar');
          bar.css('background-color', 'green');
        };
        console.log();
        if (pathToVideo != undefined) {
          index.youtubeUploadVideo(pathToVideo, processProgress, onSuccess);
        } else {
          var msg = 'Sorry, but there is some error occurred!';
          message(msg, 'error');
        }

        //index.youtubeAuthorize('youtubeUploadVideo', '');
      });
//-------------------------------------------------------

    };
    img.src = app.imageOut;

    $('#save').click(function () {
      clearCss($head);
      $body.children().not('script, .header, #msg').remove();
      require(linkHelper.getJs('save.js'))(videoGramPreview);
    });

    $('#addText').click(function () {
      require(linkHelper.getJs('addText.js'))();
    });

    function howRandomize(file, cb) {
      $('.videoGramContainer').remove();
      $btns.css('display', 'none');
      $('.back, .header .flex').css('display', 'none');
      $('.vydeoGramPreview').children().not('.caption').remove();
      $body.find('.caption').after($('<div class="progress">'));
      $body.find('.caption').text('Randomizing VydeoGram');
      var $pr = $('.progress');
      require(linkHelper.getJs(file))($pr, function (imageOut) {
        $('.back, .header .flex').css('display', '');
        videoGramPreview();
        $body.find('.caption').text('videoGram Preview');
        if (cb)cb()
      });
    }

    if (app.randomizeNot) {
      $('#randomize,#randomizePreSelect').css('display', 'none');
      (new BackHelp($('.back'))).add(function () {
        //MyProjects.myPrOrNotClick(true);
        //(new MyProjects).get();
        $('.MyProjects').click();
      });
    } else {
      $('#randomize').click(function () {
        var oldTimeStart = app.startTime;
        var oldTimeEnd = app.endTime;
        var oldGifDuration = app.gifDuration;
        app.startTime = 0;
        app.endTime = app.duration;
        app.gifDuration = Math.round(rnd.rndMinMax(app.MIN_GIF_DURATION, app.MAX_GIF_DURATION));
        howRandomize('preSelectRandomize.js', function () {
          app.startTime = oldTimeStart;
          app.endTime = oldTimeEnd;
          app.gifDuration = oldGifDuration;
        });
      });
      $('#randomizePreSelect').click(function () {
        var oldTimeStart = app.startTime;
        var oldTimeEnd = app.endTime;
        howRandomize('preSelectRandomize.js', function () {
          app.startTime = oldTimeStart;
          app.endTime = oldTimeEnd;
        });
      });
      (new BackHelp($('.back'))).add(app.back[1]);
    }
  }));
};
