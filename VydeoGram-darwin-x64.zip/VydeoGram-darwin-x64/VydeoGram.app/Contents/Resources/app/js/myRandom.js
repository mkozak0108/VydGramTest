"use strict";

module.exports = {
  rnd: function() {
    return Math.random();
  },
  rndMinMax: function(min, max) {
    return Math.random() * (max - min) + min;
  },
  rndMinMaxFix: function(min, max, fixedNumber) {
    return parseFloat(this.rndMinMax(min, max).toFixed(fixedNumber));
  }
};