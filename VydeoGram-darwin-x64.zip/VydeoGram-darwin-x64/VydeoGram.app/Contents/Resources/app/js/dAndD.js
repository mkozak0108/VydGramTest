"use strict";

function dandD() {
  var fs = require('fs');
  var path = require('path');
  var sep = path.sep;
  var linkHelper = require('..' + sep + 'js' + sep + 'linkHelper');
  var app = require(linkHelper.getJs('app.js'));
  var BackHelp = require(linkHelper.getJs('backHelp.js'));
  var MyProjects = require(linkHelper.getJs('myProjects.js'));

  var ACCEPTED_FORMATS = /3g2|3gp|4xm|a64|aac|ac3|act|adf|adp|adts|adx|aea|afc|aiff|alaw|alias_pix|amr|anm|apc|ape|apng|aqtitle|asf|asf_stream|ass|ast|au|avfoundation|avi|avm2|avr|avs|bethsoftvid|bfi|bin|bink|bit|bmp_pipe|bmv|boa|brender_pix|brstm|c93|caf|cavsvideo|cdg|cdxl|cine|concat|crc|dash|data|daud|dfa|dirac|dnxhd|dpx_pipe|dsf|dsicin|dts|dtshd|dv|dvd|dxa|ea|ea_cdata|eac3|epaf|exr_pipe|f32be|f32le|f4v|f64be|f64le|ffm|ffmetadata|film_cpk|filmstrip|flac|flic|flv|framecrc|framemd5|frm|g722|g723_1|g729|gif|gsm|gxf|h261|h263|h264|hds|hevc|hls|applehttp|hnm|ico|idcin|idf|iff|ilbc|image2|image2pipe|ingenient|ipmovie|ipod|ircam|ismv|iss|iv8|ivf|j2k_pipe|jacosub|jpeg_pipe|jpegls_pipe|jv|latm|lavfi|libmodplug|live_flv|lmlm4|loas|lrc|lvf|lxf|m4v|matroska|webm|md5|mgsts|microdvd|mjpeg|mkvtimestamp_v2|mlp|mlv|mm|mmf|mov|mp4|m4a|mj2|mp2|mp3|mpc|mpc8|mpeg|mpeg1video|mpeg2video|mpegts|mpegtsraw|mpegvideo|mpjpeg|mpl2|mpsub|msnwctcp|mtv|mulaw|mv|mvi|mxf|mxf_d10|mxg|nc|nistsphere|nsv|null|nut|nuv|oga|ogg|oma|opus|paf|pictor_pipe|pjs|pmp|png_pipe|psp|psxstr|pva|pvf|qcp|r3d|rawvideo|realtext|redspark|rl2|rm|roq|rpl|rsd|rso|rtp|rtsp|s16be|s16le|s24be|s24le|s32be|s32le|s8|sami|sap|sbg|sdp|sdr2|segment|sgi_pipe|shn|siff|sln|smjpeg|smk|smoothstreaming|smush|sol|sox|spdif|spx|srt|stl|stream_segment|ssegment|subviewer|subviewer1|sunrast_pipe|sup|svcd|swf|tak|tedcaptions|tee|thp|tiertexseq|tiff_pipe|tmv|truehd|tta|tty|txd|u16be|u16le|u24be|u24le|u32be|u32le|u8|uncodedframecrc|vc1|vc1test|vcd|vivo|vmd|vob|vobsub|voc|vplayer|vqf|w64|wav|wc3movie|webm_dash_manifest|webp|webp_pipe|webvtt|wsaud|wsvqa|wtv|wv|xa|xbin|xmv|xwma|yop|yuv4mpegpipe/;
//ACCEPTED_FORMATS=/zip/; for testing
  var ffmpeg = require('fluent-ffmpeg');
  var ffmpegFlu = require('ffmpeg-static');
  ffmpeg.setFfmpegPath(ffmpegFlu.path);

  BackHelp.clear();
  $('.back').remove();

  $('#msg').after('<div class="centrBack absolute DAndDContainer">');
  var $DAndD = $('.DAndDContainer');
  if ($DAndD.length) {
    $('head').append('<link rel="stylesheet" href="../css/dAndD.css"/>');
    $DAndD.load("dAndD.html", function () {
      //.header .btn-new
      var $newBtn = $('.header .btn-new');
      $newBtn.off('click');
      $newBtn.addClass('pushed');

      MyProjects.myPrOrNotClick(false);
      app.whereBackMyProjects = 0;


      var fileBox = $DAndD.find('.fileBox');

      function checkFormat(type) {
        if (type.indexOf('video') < 0)return true;
        return !!(type.match(ACCEPTED_FORMATS) == ""
        || type.match(ACCEPTED_FORMATS) == [""]
        || !type.match(ACCEPTED_FORMATS));
      }

      function handleFileDrop(fileTmp, $DAndD) {
        message();
        if (checkFormat(fileTmp.type)) {
          message("'" + fileTmp.name + "' : type of the file is not supported by this app." +
            " Please check the selected file.", 'error');
        } else {

          app.uploadedFile = "";
          app.uploadedFile = fileTmp;
          app.startTime = undefined;
          app.endTime = undefined;
          app.gifDuration = undefined;
          $DAndD.find('.font').text(fileTmp.name);
          $DAndD.remove();
          app.randomizeNot = false;
          $('head link[href="../css/dAndD.css"]').remove();
          require('..' + sep + 'js' + sep + 'convert.js')();
        }
      }

      $DAndD.find('.choseFile').on('click', function () {
        $(this).closest('.DAndDContainer').find('.fileBox').click();
      });
      fileBox.on('change', function (e) {
        e.preventDefault();
        if (e.target.files.length) {
          var file = e.target.files[0];
          var $DAndDLoc = $(this).closest('.DAndDContainer');
          handleFileDrop(file, $DAndDLoc);
        }
      });
      $DAndD.on('dragleave', function (e) {
        e.stopPropagation();
        e.preventDefault();
        $(this).find('.DAndDGrey').css('border', '');
      });
      $DAndD.on('dragenter', function (e) {
        e.stopPropagation();
        e.preventDefault();
        $(this).find('.DAndDGrey').css('border', '2px solid #0B85A1');
      });
      $DAndD.on('dragover', function (e) {
        e.stopPropagation();
        e.preventDefault();
      });
      $DAndD.on('drop', function (e) {
        $(this).css('border', '0');
        e.preventDefault();
        var file = e.originalEvent.dataTransfer.files[0];
        var $DAndDLoc = $(this).closest('.DAndDContainer');
        //We need to send dropped files to Server
        handleFileDrop(file, $DAndDLoc);
        $DAndDLoc.find('.DAndDGrey').css('border', '');
      });
    });
  }
}
var done = false;
window.onbeforeunload = function (e) {
  console.log('close');
  var path = require('path');
  var fs = require('fs');
  var sep = path.sep;
  var linkHelper = require('..' + sep + 'js' + sep + 'linkHelper.js');
  var app = require(linkHelper.getJs('app.js'));
  if (done)return true;
  app.clearTemp(function () {
    done = true;
    window.close();
  });
  return done;
};
dandD();
module.exports = dandD;
//module.exports = dandD;
