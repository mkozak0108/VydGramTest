
"use strict";

var path = require('path');
var sep = path.sep;
var remote = require('remote');
var amember = require('../js/amember.js');
var fs = require('fs');
var app = require('../js/app.js');

// var linkHelper = require('../js/linkHelper.js');
// var app = require('../js/app.js');
// // require('../js/mainBack.js');

$(function () {
  $('.license-key').focus();
  $('.loginBtn').click(function () {
    showLoader();
    function updateLicense(licenseKey, lastCheckDate) {
      var mainPath = app.mainPath;
      var pathToLicense = path.join(mainPath, 'license', 'license.json');
      console.log(mainPath, '-------');
      var license = {
        'license': licenseKey,
        'lastCheckDate': lastCheckDate
      };
      var text = JSON.stringify(license);
      fs.writeFile(pathToLicense, text, function (err) {
        if (err) {
          return console.log(err);
        }
        console.log("The file was saved!");
      });
    }

    var licenseKey = $('.license-key').val();
    //console.log(licenseKey);

    function showMsg(msg) {
        message(msg, 'error');
    };

    var onlineChecker = function () {
      if (navigator.onLine) {
        showMsg('Sorry, but some server error occurred. Please try to activate license later.');
        hideLoader();
      } else {
        showMsg('You must be online to activate license.');
        hideLoader();
      }
    }

    var index = require('remote').require('./index.js');

    //if (licenseKey != 'qwerty') {//------------------Hack---------------------------------
      //amember.logIn(licenseKey, '', showMsg, function () {//shold be
      //  window.location.href = '..' + sep + 'views' + sep + 'mainBack.html';//shold be
      //  //updateLicense(licenseKey, new Date());//shold be
      //}, '', function () {
      //  if (navigator.onLine) {
      //    showMsg('Sorry, but some server error occurred. Please try to activate license later.');
      //  } else {
      //    showMsg('You must be online to activate license.');
      //  }
      //});//shold be
      if (licenseKey === '') {
        showMsg('License key cannot be empty.');
        hideLoader();
      } else {
        index.logIn(licenseKey, onlineChecker);
      }
    //} else {//----------------------------------------------------------------
    //  updateLicense(licenseKey, new Date());
    //  index.loadStartPage();
    //}

  });//----------------------------------------------------------------------


  $('body').keypress(function (event) {
    if (event.which == 13) {
      $('.loginBtn').trigger('click');
    }
  });


});

function resetQuit() {
  app.clearTemp(function () {
    window.onbeforeunload = function(){}
  });
}

function showLoader() {
  $('.boxForLoader').css('display', 'none');
  $('.login-loader, .login-loader img').css('display', '');
}

function hideLoader() {
  $('.login-loader,.login-loader img').css('display', 'none');
  $('.boxForLoader').css('display', 'block');
}