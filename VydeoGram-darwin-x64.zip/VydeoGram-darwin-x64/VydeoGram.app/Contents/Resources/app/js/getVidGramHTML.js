module.exports = function ($container, cb, base64OrNot) {
  $container.load("videoGram.html", function () {
    var fs = require('fs');
    var path = require('path');
    var sep = path.sep;
    var linkHelper = require('..' + sep + 'js' + sep + 'linkHelper');
    var app = require(linkHelper.getJs('app.js'));
    var ffmpegHelp = require(linkHelper.getJs("ffmpegHelp.js"));

    var $funcContainer = $container.find('.outBlock');
    $funcContainer.find('.imgPreview').attr("src", app.imageOut);

    var tempfolder = linkHelper.getTempPath() + sep;

    function doEnd(base64OrNot) {
      var srcs = [];
      srcs.push(tempfolder + 'screen.png');
      for (var i = 1; i <= 3; ++i)srcs.push(tempfolder + 'screen_' + i + '.png');

      function cbAll() {
        $funcContainer.find('.row-1 .screen').first().attr('src', srcs[0]);
        $funcContainer.find('.row-1 .screen').last().attr('src', srcs[1]);
        $funcContainer.find('.row-2 .screen').first().attr('src', srcs[2]);
        $funcContainer.find('.row-2 .screen').last().attr('src', srcs[3]);
        if (cb)cb();
      }

      if (base64OrNot) {
        /**
         * @param  {Number} index - {srcs[index]}
         * @param  {Function} callback
         * @param  {String}   [outputFormat=image/png]
         */
        function convertImgToBase64(index, callback, outputFormat) {
          var img = new Image();
          img.crossOrigin = 'Anonymous';
          img.onload = function () {
            var canvas = document.createElement('CANVAS');
            var ctx = canvas.getContext('2d');
            canvas.height = this.height;
            canvas.width = this.width;
            ctx.drawImage(this, 0, 0);
            var dataURL = canvas.toDataURL(outputFormat || 'image/png');
            console.log('convertImgToBase64 ' + index);
            callback(dataURL, index);
            canvas = null;
          };
          img.src = srcs[index];
        }

        var indexOut = 0;

        function cbConvFunc(dataURL, index) {

          console.log('cbConvFunc ' + index);
          if (indexOut <= 3) {
            srcs[index] = dataURL;
          }
          if (indexOut == 3) {
            cbAll();
          }
          ++indexOut;
        }

        function cb64Base(index) {
          console.log('cb64Base ' + index);
          if (index <= 3) {
            convertImgToBase64(index, cbConvFunc);
            ++index;
            cb64Base(index)
          }
        }

        cb64Base(0);
      } else {
        cbAll();
      }
    }

    var times2 = [];
    var duration = app.endTime - app.startTime;

    function partDuration(fractal, degits) {
      return parseFloat((app.startTime + (duration * fractal)).toFixed(degits));
    }

    //times2.push(partDuration(0, 3));
    times2.push(partDuration(0.333, 3));
    times2.push(partDuration(0.666, 3));
    times2.push(partDuration(0.99, 3));
    function cbGetScreens(filenames) {
      for (var i = 0; i < filenames.length; ++i) {
        app.addToDelete(filenames[i]);
      }
      doEnd(base64OrNot);
    }

    ffmpegHelp.getScreen2(app.uploadedFile.path, app.startTime, linkHelper.getTempPath() + sep + 'screen.png',
      function () {
        ffmpegHelp.getScreens3(app.uploadedFile.path, linkHelper.getTempPath() + sep + 'screen_%d.png',
          times2, cbGetScreens);
      });
  });

};
