/**
 * Created by petropavlenko on 9/21/15.
 */
module.exports = function (cancle, cancleParams) {
  var fs = require('fs');
  var path = require('path');
  var sep = path.sep;
  var linkHelper = require('..' + sep + 'js' + sep + 'linkHelper.js');
  var app = require(linkHelper.getJs('app.js'));
  var dialog = require('remote').require('dialog');
  //var GetVidHTML = require(linkHelper.getJs("getVidGramHTML.js"));
  var getVIDImgs = require(linkHelper.getJs('getVIDImgs.js'));
  var BackHelp = require(linkHelper.getJs('backHelp.js'));
  var gifHelp = require(linkHelper.getJs("gifHelp.js"));
  var MyProjects = require(linkHelper.getJs("myProjects"));
  var mkdirp = require(linkHelper.getJs('mkdirp'));
  var fse = require('fs.extra');

  var $body = $('body');
  var $head = $('head');
  var $saveOrCancel;

  //$body.children().not('script, .header, #msg').remove();
  function clearCss($head) {
    $head.find('link')
      .not('link[href="../css/mainBtns.css"]')
      .not('link[href="../css/mainBack.css"]')
      .remove();
  }

  BackHelp.clear();
  clearCss($head);
  $head.append('<link rel="stylesheet" href="../css/save.css"/>');

  $body.append($('<div>').load('save.html', function () {
    $('.where .textArea').val(require('remote').require('app').getPath('userDesktop') + sep + "VydeoGram");
    $saveOrCancel = $('.saveOrCancel');
    $saveOrCancel.find('.cancel').click(function () {
      message();
      cancle.call(this, cancleParams);
    });
    var $where = $body.find('.where');
    var $folderNamePath = $where.find('.textArea');
    $where.find('.listIcon').click(function () {
      var newPath = dialog.showOpenDialog({
        title: 'Please select/create folder',
        properties: ['openDirectory', 'createDirectory']
      }, function (folder) {
        if(folder)
        $folderNamePath.val(folder);
      });
    });
    $saveOrCancel.find('.saveBtn').click(function () {
      var name = $body.find('.name input.textArea').val();
      //var dir = $folderNamePath.val() + sep + $body.find('.name input.textArea').val() + ".html";
      var dir = $folderNamePath.val() + sep + name + ".gif";

      function copy(src, dest) {
        var oldFile = fs.createReadStream(src);
        var newFile = fs.createWriteStream(dest);
        oldFile.pipe(newFile);
      };

      function save() {
        //message('saving', 'hint');
        var $toDisable = $('.btn, .back');
        $toDisable.attr('disable');
        mkdirp($folderNamePath.val(), function (err) {
          if (err) {
            message(err, 'error');
            console.error(err);
          } else {
            var newDir = MyProjects.getFolderName(name);
            var json = MyProjects.getJson(app.appDataPrNameDir);
            json.prNameDir = newDir;
            MyProjects.setJson(app.appDataPrNameDir, json);
            if (err) {
              console.log(err);
              message(err, 'error');
            }
            app.imageOut = app.appDataPrNameDir + sep + 'gif.gif';
            fse.copy(app.imageOut, dir, {replace: true}, function (err) {
              $('.MyProjects').click();
            });
          }
        });
      }

      if (fs.existsSync(dir)) {
        message(' VydeoGram exists, replace? ', 'hint', {
          name: 'messageYesNo',
          yesFunc: function () {
            save();
          },
          noFunc: function () {
            message();
          }
        });
      } else {
        save();
      }
    });
    (new BackHelp($('.back'))).add(cancle, cancleParams);
  }));
};
