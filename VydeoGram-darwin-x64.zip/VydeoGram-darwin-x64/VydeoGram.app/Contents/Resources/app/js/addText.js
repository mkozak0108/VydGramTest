"use strict";
module.exports = function addText() {
  var fs = require('fs');
  var path = require('path');
  var sep = path.sep;
  var linkHelper = require('..' + sep + 'js' + sep + 'linkHelper');
  var app = require(linkHelper.getJs('app.js'));
  var createGifFunc = require(linkHelper.getJs("createGifFunc.js"));
  var ffmpegHelp = require(linkHelper.getJs("ffmpegHelp.js"));
  var BackHelp = require(linkHelper.getJs('backHelp.js'));
  //var convert = require(linkHelper.getJs('convert.js'));
  var timeTransform = require(linkHelper.getJs("timeTransform.js"));
  var MyProjects = require(linkHelper.getJs('myProjects.js'));
  var Slider = require(linkHelper.getJs('slider.js'));
  var BootsrapSlider = require(linkHelper.getAbsolute('vendor', 'js', 'bootstrap-slider.min.js'));

  var FIRST_SCREEN_NAME = 'forSave_1.png';

  var $body = $('body');
  var $head = $('head');
  BackHelp.clear('#msg, .header, script, .back, .forbidden-icon.hide');

  $head.append('<link rel="stylesheet" href="../css/addText.css"/>');
  $head.append('<link rel="stylesheet" href="../css/roundProgressBar.css"/>');
  $('<link rel="stylesheet" href="../vendor/css/bootstrap-slider.min.css"/>')
    .insertBefore('link[href="../css/mainBtns.css"]');

  $('#msg').after($('<div>').load('addText.html', function () {

    var jsonInf = MyProjects.getJson(app.appDataPrNameDir);

    var min = 0;
    var max = jsonInf.gifDuration;
    var gifDOM;

    var step = 1;
    var slider = new Slider('.left', step, max, min);
    $('.textEdit.second').val(timeTransform.toStrFromSeconds(max));

    var $loader = $('.loader');

    $loader.after('<img id="gif">');
    gifDOM = $('#gif')[0];
    gifDOM.onload = function () {
      $loader.remove();
    };
    gifDOM.src = app.appDataPrNameDir + sep + FIRST_SCREEN_NAME;

    var str$whereTime = '.video-player .staus-time';
    var $slideTime = $(str$whereTime);
    $slideTime.attr('data-max-value', max);
    $slideTime.attr('data-min-value', min);
    $slideTime.attr('data-slider-step', step);
    $slideTime.attr('data-slider-value', min);
    var sliderTime = new BootsrapSlider(str$whereTime, {
      tooltip: 'hide',
      max: max
    });
    require(linkHelper.getAbsolute('vendor', 'select2', 'js', 'select2.js'));

    $('<link href="' + linkHelper.getAbsolute('vendor', 'select2', 'css', 'select2.css') + '" rel="stylesheet" />')
      .insertBefore('link[href="../css/mainBtns.css"]');
    $body.append('<script src="' + linkHelper.getAbsolute('vendor', 'select2', 'js', 'select2.js') + '"></script>');
    $(".fonts-select").select2({
    });

    $(".fonts-color-select").select2({
    });

    (new BackHelp($('.back'))).add(app.back[2]);
  }));
};

