"use strict";

function dropDown(where$str, options) {
  var fs = require('fs');
  var path = require('path');
  var sep = path.sep;
  var linkHelper = require('..' + sep + 'js' + sep + 'linkHelper');
  var app = require(linkHelper.getJs('app.js'));
  $('head').append($('<link href="../vendor/select2/css/select2.css" rel="stylesheet" />'));
  $('body').append($('<script src="../vendor/select2/js/select2.js"></script>'));

}

module.exports = dropDown;