"use strict";

var fs = require('fs');
var path = require('path');
var sep = path.sep;
var rimraf = require('rimraf');
//var linkHelper = require('..' + sep + 'js' + sep + 'linkHelper');
var unDone = true;
var app = {
  mainPath: "",
  uploadedFile: undefined,
  imageOut: undefined,
  MAX_SCREENS: 175,
  MAX_GIF_DURATION: 30,
  MIN_GIF_DURATION: 4,
  MAX_INTERVAL_DEFERENCE: 2,
  PRIORITY_SEGMENT_DURATION: 5,
  ON_PROGRESS_TIMEOUT: 200,
  interval: 0,   //0.1sec
  intervalIn: 0, //10sec
  duration: 0,
  startTime: 0,
  endTime: 0,
  gifDuration: 4,
  screens: [],//{name: 'path/to/screan/asd/asd.png', value: 21123 }  (value - time in seconds)
  garbage: [],
  width: 277,
  height: 312,
  quality: 1,
  saveGifLink: [],
  randomizeNot: false,
  whereBackMyProjects: undefined,
  appDataPrNameDir: "",
  back: ['dAndD.js', 'convert.js', 'videoGramPreview.js', 'save.js'],
  deleteGarbage: function (cb) {
    var garbage = this.garbage;

    function del(index) {
      fs.unlink(garbage[index], function (err) {
        if (err) {
          console.log('error while deleted: ' + garbage[index]);
          console.log(err.message);
        } else console.log('successfully deleted :' + garbage[index]);
        ++index;
        if (index < garbage.length) {
          del(index);
        } else {
          module.exports.garbage.length = 0;
          if (cb) cb();
        }
      });
    }

    if (garbage.length) del(0);
  },
  clearTemp: function (cb) {
    var path = require('path');
    var fs = require('fs');
    var sep = path.sep;
    var linkHelper = require('..' + sep + 'js' + sep + 'linkHelper.js');
    var temp = linkHelper.getTempPath();

    function end() {
      module.exports.garbage.length = 0;
      unDone = false;
      if (cb)cb();
    }

    if (fs.existsSync(temp) && fs.readdirSync(temp).length) {
      rimraf(temp, function () {
        end();
      });
    } else {
      end();
    }
  },
  addToDelete: function (namePath) {
    if (this.garbage.indexOf(namePath) < 0) {
      this.garbage.push(namePath);
    }
  }
};
module.exports = app;
module.exports.mainPath = __dirname.substring(0, __dirname.lastIndexOf('js') - 1);


