"use strict";

module.exports = function ($progressBarBox, cb) {

  var fs = require('fs');
  var path = require('path');
  var sep = path.sep;
  var linkHelper = require('..' + sep + 'js' + sep + 'linkHelper');
  var timeTransform = require(linkHelper.getJs("timeTransform.js"));
  var gifHelp = require(linkHelper.getJs("gifHelp.js"));
  var ffmpegHelp = require(linkHelper.getJs("ffmpegHelp.js"));
  var rnd = require(linkHelper.getJs('myRandom.js'));
  var app = require(linkHelper.getJs('app.js'));

  var $head = $('head');
  $head.append('<link rel="stylesheet" href="../css/roundProgressBar.css"/>');
  //var MAX_LUFT = 1;
  //var MAX_SCREENS = app.MAX_SCREENS;
  //var MIN_SCREENS = 3;

  $progressBarBox.load('roundProgressBar.html', function () {
    function round(input, degits) {
      return parseFloat(input.toFixed(degits));
    }

    var durationGram = app.endTime - app.startTime;
    var newStart = app.startTime;
    var newEnd = app.endTime;
    var start2 = round(newEnd - app.gifDuration, 3);
    if (start2 < app.startTime)start2 = app.startTime;
    var index = 0;
    do {
      newStart = rnd.rndMinMax(app.startTime, start2);
      newEnd = rnd.rndMinMax(newStart, app.endTime);
      console.log('randomize: ' + newStart + "  " + newEnd);
    } while ((newEnd - newStart) < app.MIN_GIF_DURATION ||
    app.gifDuration / (newEnd - newStart) > app.MAX_INTERVAL_DEFERENCE);
    //{
    //  ffmpegHelp.getTimes(newStart, newEnd);
    //  newEnd = rnd.rndMinMax(newStart, app.endTime);
    //}

    app.startTime = newStart;
    app.endTime = newEnd;
    function cbGifCreate(imageOut) {
      //app.imageOut = imageOut;
      $progressBarBox.empty();
      $head.find('link[href="../css/roundProgressBar.css"]').remove();
      cb(imageOut);
    }

    app.clearTemp(function () {
      var timeOut = ffmpegHelp.getTimes(newStart, newEnd);
      require(linkHelper.getJs('createGifFunc.js'))(app.uploadedFile.path, timeOut,
        app.width, app.height, app.quality, '.roundProgressBar', cbGifCreate);
    });

  });
};