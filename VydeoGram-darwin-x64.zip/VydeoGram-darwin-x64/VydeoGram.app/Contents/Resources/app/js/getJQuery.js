"use strict";

window.$ = "";
window.jquery = "";
window.jQuery = "";
window.linkHelper = "";
//window.memwatch = "";
(function get() {
  var path = require('path');
  var sep = path.sep;
  //window.memwatch = require('memwatch');
  window.linkHelper = require('..' + sep + 'js' + sep + 'linkHelper.js');
  window.jquery = window.$ = window.jQuery = require(linkHelper.getAbsolute('vendor', 'js', 'jquery.min.js'));
})();