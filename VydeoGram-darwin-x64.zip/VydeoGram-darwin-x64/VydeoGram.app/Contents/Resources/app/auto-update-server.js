var express = require('express'),
  app = express();


app.listen(6666, () => {
  console.log('Server Started, 6666')
});


app.get('/', (req, res) => {
  var data = {
    "url": "file:///Users/MU/vydeogram-app/builds/mac/VydeoGram-darwin-x64.zip",
    "name": "My Release Name",
    "notes": "Theses are some release notes innit",
    "pub_date": "2013-09-18T12:29:53+01:00"
  };
  res.send(data);
});
